package com.justiceserve.controller;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.Role;
import com.justiceserve.entity.Status;
import com.justiceserve.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * UserController – User management (ADMIN only).
 * Base URL: /api/users
 *
 * Angular Integration:
 *  - All requests require Authorization: Bearer <token>
 *  - Only users with role=ADMIN can access these endpoints
 *  - GET    /api/users           → Admin user list table
 *  - GET    /api/users/{id}      → User detail view
 *  - PATCH  /api/users/{id}/status?status=INACTIVE → Deactivate user
 *  - DELETE /api/users/{id}      → Remove user
 */
@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
@Tag(name = "User Management", description = "Admin: manage system users")
public class UserController {

    private final UserService userService;

    /** GET /api/users – Returns all users. Angular admin table. */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get all users")
    public ResponseEntity<List<UserResponse>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    /** GET /api/users/{id} */
    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get user by ID")
    public ResponseEntity<UserResponse> getUser(@PathVariable Long id) {
        return ResponseEntity.ok(userService.getUserById(id));
    }

    /** GET /api/users/role/{role} – Filter by role for dropdowns. */
    @GetMapping("/role/{role}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE')")
    @Operation(summary = "Get users by role", description = "Useful for populating judge/lawyer dropdowns in Angular")
    public ResponseEntity<List<UserResponse>> getByRole(@PathVariable Role role) {
        return ResponseEntity.ok(userService.getUsersByRole(role));
    }

    /** PATCH /api/users/{id}/status?status=INACTIVE */
    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update user status (ACTIVE/INACTIVE)")
    public ResponseEntity<UserResponse> updateStatus(@PathVariable Long id, @RequestParam Status status) {
        return ResponseEntity.ok(userService.updateUserStatus(id, status));
    }

    /** DELETE /api/users/{id} */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete user")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}
