package com.justiceserve.controller;

import com.justiceserve.dto.request.CitizenRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CitizenResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.VerificationStatus;
import com.justiceserve.service.CitizenService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * CitizenController – Citizen profile and document management.
 * Base URL: /api/citizens
 *
 * Angular Integration:
 *  POST   /api/citizens                              → Admin/Clerk creates citizen profile
 *  GET    /api/citizens                              → Admin/Clerk citizen list
 *  GET    /api/citizens/{id}                         → Citizen profile page
 *  GET    /api/citizens/user/{userId}                → My Profile (current user)
 *  PUT    /api/citizens/{id}                         → Edit profile form
 *  POST   /api/citizens/{id}/documents               → Upload document (multipart or URI)
 *  GET    /api/citizens/{id}/documents               → Document list
 *  PATCH  /api/citizens/{id}/documents/{docId}/verify?status=VERIFIED → Clerk verification
 */
@RestController
@RequestMapping("/api/citizens")
@RequiredArgsConstructor
@Tag(name = "Citizen Management", description = "Citizen registration, profile and documents")
public class CitizenController {

    private final CitizenService citizenService;

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','CLERK')")
    @Operation(summary = "Create citizen profile")
    public ResponseEntity<CitizenResponse> create(@Valid @RequestBody CitizenRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(citizenService.createCitizen(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all citizens")
    public ResponseEntity<List<CitizenResponse>> getAll() {
        return ResponseEntity.ok(citizenService.getAllCitizens());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','CITIZEN','LAWYER','JUDGE','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get citizen by ID")
    public ResponseEntity<CitizenResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(citizenService.getCitizenById(id));
    }

    /** Angular: Call with logged-in userId to get the citizen's own profile. */
    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','CITIZEN')")
    @Operation(summary = "Get citizen profile by User ID")
    public ResponseEntity<CitizenResponse> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(citizenService.getCitizenByUserId(userId));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','CITIZEN')")
    @Operation(summary = "Update citizen profile")
    public ResponseEntity<CitizenResponse> update(@PathVariable Long id, @Valid @RequestBody CitizenRequest request) {
        return ResponseEntity.ok(citizenService.updateCitizen(id, request));
    }

    @PostMapping("/{id}/documents")
    @PreAuthorize("hasAnyRole('CITIZEN','LAWYER','CLERK','ADMIN')")
    @Operation(summary = "Upload citizen document", description = "Send fileUri (storage path). Returns document with PENDING status.")
    public ResponseEntity<DocumentResponse> addDoc(@PathVariable Long id, @Valid @RequestBody DocumentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(citizenService.addDocument(id, request));
    }

    @GetMapping("/{id}/documents")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','CITIZEN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get citizen documents")
    public ResponseEntity<List<DocumentResponse>> getDocs(@PathVariable Long id) {
        return ResponseEntity.ok(citizenService.getDocuments(id));
    }

    /** Angular Clerk panel: verify/reject identity documents. */
    @PatchMapping("/{citizenId}/documents/{docId}/verify")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK')")
    @Operation(summary = "Verify citizen document", description = "Clerk sets status: VERIFIED or REJECTED")
    public ResponseEntity<DocumentResponse> verifyDoc(
            @PathVariable Long citizenId, @PathVariable Long docId,
            @RequestParam VerificationStatus status) {
        return ResponseEntity.ok(citizenService.verifyDocument(docId, status));
    }
}
