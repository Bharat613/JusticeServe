package com.justiceserve.controller;

import com.justiceserve.dto.request.LoginRequest;
import com.justiceserve.dto.request.RegisterRequest;
import com.justiceserve.dto.response.AuthResponse;
import com.justiceserve.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * AuthController – Public endpoints (no JWT required).
 * Base URL: /api/auth
 *
 * Angular Integration:
 *  - POST /api/auth/register → send RegisterRequest JSON, receive AuthResponse with JWT
 *  - POST /api/auth/login    → send LoginRequest JSON, receive AuthResponse with JWT
 *  - Store response.token in localStorage
 *  - Attach to every request: HttpHeaders.set('Authorization', 'Bearer ' + token)
 */
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Register and Login – returns JWT token")
public class AuthController {

    private final AuthService authService;

    /**
     * POST /api/auth/register
     * Body: { name, email, password, role, phone }
     * Returns: { token, tokenType, userId, name, email, role }
     * Angular: Use for registration form. Store token after success.
     */
    @PostMapping("/register")
    @Operation(summary = "Register new user", description = "Creates user account and returns JWT token")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }

    /**
     * POST /api/auth/login
     * Body: { email, password }
     * Returns: { token, tokenType, userId, name, email, role }
     * Angular: Login form submits here. Store token + role to control route access.
     */
    @PostMapping("/login")
    @Operation(summary = "Login", description = "Authenticate and receive JWT token")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody LoginRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }
}
