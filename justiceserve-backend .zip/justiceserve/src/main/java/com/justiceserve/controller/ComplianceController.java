package com.justiceserve.controller;

import com.justiceserve.dto.request.AuditRequest;
import com.justiceserve.dto.request.ComplianceRecordRequest;
import com.justiceserve.dto.response.AuditResponse;
import com.justiceserve.dto.response.ComplianceRecordResponse;
import com.justiceserve.entity.AuditStatus;
import com.justiceserve.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * ComplianceController – Compliance records and audits.
 * Base URL: /api/compliance  and  /api/audits
 *
 * Angular Integration:
 *  POST   /api/compliance              → Compliance officer: Add record
 *  GET    /api/compliance              → Compliance list
 *  GET    /api/compliance/{id}         → Record detail
 *  PATCH  /api/compliance/{id}         → Update result/notes
 *
 *  POST   /api/audits                  → Start an audit
 *  GET    /api/audits                  → Audit list (Government Auditor dashboard)
 *  GET    /api/audits/{id}             → Audit detail
 *  PATCH  /api/audits/{id}/status      → Close/review audit
 */
@RestController
@RequiredArgsConstructor
@Tag(name = "Compliance & Audit", description = "Compliance records and formal audits")
public class ComplianceController {

    private final ComplianceService complianceService;

    @PostMapping("/api/compliance")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    @Operation(summary = "Create compliance record")
    public ResponseEntity<ComplianceRecordResponse> create(@Valid @RequestBody ComplianceRecordRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(complianceService.createRecord(req));
    }

    @GetMapping("/api/compliance")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','AUDITOR')")
    @Operation(summary = "Get all compliance records")
    public ResponseEntity<List<ComplianceRecordResponse>> getAll() {
        return ResponseEntity.ok(complianceService.getAllRecords());
    }

    @GetMapping("/api/compliance/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','AUDITOR')")
    @Operation(summary = "Get compliance record by ID")
    public ResponseEntity<ComplianceRecordResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(complianceService.getRecordById(id));
    }

    @PatchMapping("/api/compliance/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    @Operation(summary = "Update compliance record result/notes")
    public ResponseEntity<ComplianceRecordResponse> update(
            @PathVariable Long id, @Valid @RequestBody ComplianceRecordRequest req) {
        return ResponseEntity.ok(complianceService.updateRecord(id, req));
    }

    // ── Audit endpoints ────────────────────────────────────────────

    @PostMapping("/api/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Create audit")
    public ResponseEntity<AuditResponse> createAudit(@Valid @RequestBody AuditRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(complianceService.createAudit(req));
    }

    @GetMapping("/api/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Get all audits")
    public ResponseEntity<List<AuditResponse>> getAllAudits() {
        return ResponseEntity.ok(complianceService.getAllAudits());
    }

    @GetMapping("/api/audits/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Get audit by ID")
    public ResponseEntity<AuditResponse> getAudit(@PathVariable Long id) {
        return ResponseEntity.ok(complianceService.getAuditById(id));
    }

    @PatchMapping("/api/audits/{id}/status")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Update audit status (OPEN/CLOSED/REVIEW)")
    public ResponseEntity<AuditResponse> updateAuditStatus(@PathVariable Long id, @RequestParam AuditStatus status) {
        return ResponseEntity.ok(complianceService.updateAuditStatus(id, status));
    }
}
