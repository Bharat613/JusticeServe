package com.justiceserve.controller;

import com.justiceserve.dto.request.CourtOrderRequest;
import com.justiceserve.dto.request.JudgmentRequest;
import com.justiceserve.dto.response.CourtOrderResponse;
import com.justiceserve.dto.response.JudgmentResponse;
import com.justiceserve.entity.OrderStatus;
import com.justiceserve.service.JudgmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * JudgmentController – Judgment and court order management.
 * Base URL: /api/judgments  and  /api/court-orders
 *
 * Angular Integration:
 *  POST   /api/judgments                       → Judge: Record judgment form
 *  GET    /api/judgments                       → Judgments list
 *  GET    /api/judgments/{id}                  → Judgment detail
 *  GET    /api/judgments/case/{caseId}         → Judgments for a case
 *  PATCH  /api/judgments/{id}/finalize         → Judge: Finalize judgment (closes case)
 *
 *  POST   /api/court-orders                    → Judge: Issue order
 *  GET    /api/court-orders                    → Orders list
 *  GET    /api/court-orders/{id}               → Order detail
 *  GET    /api/court-orders/case/{caseId}      → Orders for a case
 *  PATCH  /api/court-orders/{id}/status        → Update order status
 */
@RestController
@RequiredArgsConstructor
@Tag(name = "Judgment & Orders", description = "Judgments and court orders management")
public class JudgmentController {

    private final JudgmentService judgmentService;

    // ── Judgment endpoints ────────────────────────────────────────

    @PostMapping("/api/judgments")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    @Operation(summary = "Record a judgment (DRAFT)")
    public ResponseEntity<JudgmentResponse> record(@Valid @RequestBody JudgmentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(judgmentService.recordJudgment(req));
    }

    @GetMapping("/api/judgments")
    @PreAuthorize("hasAnyRole('ADMIN','JUDGE','CLERK','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all judgments")
    public ResponseEntity<List<JudgmentResponse>> getAll() {
        return ResponseEntity.ok(judgmentService.getAllJudgments());
    }

    @GetMapping("/api/judgments/{id}")
    @Operation(summary = "Get judgment by ID")
    public ResponseEntity<JudgmentResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(judgmentService.getJudgmentById(id));
    }

    @GetMapping("/api/judgments/case/{caseId}")
    @Operation(summary = "Get judgments by case")
    public ResponseEntity<List<JudgmentResponse>> byCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(judgmentService.getJudgmentsByCase(caseId));
    }

    @PatchMapping("/api/judgments/{id}/finalize")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    @Operation(summary = "Finalize judgment", description = "Sets judgment to FINAL, closes the case, notifies citizen/lawyer")
    public ResponseEntity<JudgmentResponse> finalize(@PathVariable Long id) {
        return ResponseEntity.ok(judgmentService.finalizeJudgment(id));
    }

    // ── Court Order endpoints ─────────────────────────────────────

    @PostMapping("/api/court-orders")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    @Operation(summary = "Issue a court order")
    public ResponseEntity<CourtOrderResponse> issueOrder(@Valid @RequestBody CourtOrderRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(judgmentService.issueOrder(req));
    }

    @GetMapping("/api/court-orders")
    @PreAuthorize("hasAnyRole('ADMIN','JUDGE','CLERK','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all court orders")
    public ResponseEntity<List<CourtOrderResponse>> getAllOrders() {
        return ResponseEntity.ok(judgmentService.getAllOrders());
    }

    @GetMapping("/api/court-orders/{id}")
    @Operation(summary = "Get court order by ID")
    public ResponseEntity<CourtOrderResponse> getOrder(@PathVariable Long id) {
        return ResponseEntity.ok(judgmentService.getOrderById(id));
    }

    @GetMapping("/api/court-orders/case/{caseId}")
    @Operation(summary = "Get court orders by case")
    public ResponseEntity<List<CourtOrderResponse>> ordersByCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(judgmentService.getOrdersByCase(caseId));
    }

    @PatchMapping("/api/court-orders/{id}/status")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN','CLERK')")
    @Operation(summary = "Update court order status")
    public ResponseEntity<CourtOrderResponse> updateOrderStatus(@PathVariable Long id, @RequestParam OrderStatus status) {
        return ResponseEntity.ok(judgmentService.updateOrderStatus(id, status));
    }
}
