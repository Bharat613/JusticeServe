package com.justiceserve.controller;

import com.justiceserve.dto.request.ReportRequest;
import com.justiceserve.dto.response.ReportResponse;
import com.justiceserve.entity.ReportScope;
import com.justiceserve.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * ReportController – Analytics and report generation.
 * Base URL: /api/reports
 *
 * Angular Integration:
 *  POST   /api/reports/generate         → Admin: trigger report generation
 *  GET    /api/reports                  → Reports list
 *  GET    /api/reports/{id}             → Report detail (metrics JSON)
 *  GET    /api/reports/scope/{scope}    → Filter by CASE/HEARING/JUDGMENT/COMPLIANCE
 */
@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
@Tag(name = "Reports & Analytics", description = "Generate and retrieve analytics reports")
public class ReportController {

    private final ReportService reportService;

    @PostMapping("/generate")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Generate a report", description = "Computes metrics from DB and stores the report. Returns the saved report with metrics JSON.")
    public ResponseEntity<ReportResponse> generate(@Valid @RequestBody ReportRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(reportService.generateReport(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all reports")
    public ResponseEntity<List<ReportResponse>> getAll() {
        return ResponseEntity.ok(reportService.getAllReports());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get report by ID")
    public ResponseEntity<ReportResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(reportService.getReportById(id));
    }

    @GetMapping("/scope/{scope}")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get reports by scope")
    public ResponseEntity<List<ReportResponse>> byScope(@PathVariable ReportScope scope) {
        return ResponseEntity.ok(reportService.getReportsByScope(scope));
    }
}
