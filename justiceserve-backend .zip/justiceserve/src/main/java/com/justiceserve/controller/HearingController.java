package com.justiceserve.controller;

import com.justiceserve.dto.request.HearingRequest;
import com.justiceserve.dto.request.ProceedingRequest;
import com.justiceserve.dto.response.HearingResponse;
import com.justiceserve.dto.response.ProceedingResponse;
import com.justiceserve.entity.HearingStatus;
import com.justiceserve.service.HearingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * HearingController – Hearing scheduling and proceedings.
 * Base URL: /api/hearings
 *
 * Angular Integration:
 *  POST   /api/hearings                       → Clerk: Schedule hearing form
 *  GET    /api/hearings                       → All hearings list (judge/clerk)
 *  GET    /api/hearings/{id}                  → Hearing detail
 *  GET    /api/hearings/case/{caseId}         → Hearings for a case
 *  GET    /api/hearings/judge/{judgeId}       → Judge's hearing calendar
 *  PATCH  /api/hearings/{id}/status?status=COMPLETED → Judge: Mark hearing done
 *  POST   /api/hearings/{id}/proceedings      → Judge: Add proceeding notes
 *  GET    /api/hearings/{id}/proceedings      → Proceedings for a hearing
 */
@RestController
@RequestMapping("/api/hearings")
@RequiredArgsConstructor
@Tag(name = "Hearing Management", description = "Schedule and manage court hearings")
public class HearingController {

    private final HearingService hearingService;

    @PostMapping
    @PreAuthorize("hasAnyRole('CLERK','ADMIN','JUDGE')")
    @Operation(summary = "Schedule a hearing")
    public ResponseEntity<HearingResponse> schedule(@Valid @RequestBody HearingRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(hearingService.scheduleHearing(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all hearings")
    public ResponseEntity<List<HearingResponse>> getAll() {
        return ResponseEntity.ok(hearingService.getAllHearings());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get hearing by ID")
    public ResponseEntity<HearingResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(hearingService.getHearingById(id));
    }

    @GetMapping("/case/{caseId}")
    @Operation(summary = "Get hearings by case")
    public ResponseEntity<List<HearingResponse>> byCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(hearingService.getHearingsByCase(caseId));
    }

    @GetMapping("/judge/{judgeId}")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN','CLERK')")
    @Operation(summary = "Get hearings by judge")
    public ResponseEntity<List<HearingResponse>> byJudge(@PathVariable Long judgeId) {
        return ResponseEntity.ok(hearingService.getHearingsByJudge(judgeId));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('JUDGE','CLERK','ADMIN')")
    @Operation(summary = "Update hearing status")
    public ResponseEntity<HearingResponse> updateStatus(@PathVariable Long id, @RequestParam HearingStatus status) {
        return ResponseEntity.ok(hearingService.updateStatus(id, status));
    }

    @PostMapping("/{id}/proceedings")
    @PreAuthorize("hasAnyRole('JUDGE','CLERK','ADMIN')")
    @Operation(summary = "Add proceeding notes to hearing")
    public ResponseEntity<ProceedingResponse> addProceeding(
            @PathVariable Long id, @Valid @RequestBody ProceedingRequest request) {
        request.setHearingId(id);
        return ResponseEntity.status(HttpStatus.CREATED).body(hearingService.addProceeding(request));
    }

    @GetMapping("/{id}/proceedings")
    @Operation(summary = "Get proceedings for a hearing")
    public ResponseEntity<List<ProceedingResponse>> getProceedings(@PathVariable Long id) {
        return ResponseEntity.ok(hearingService.getProceedingsByHearing(id));
    }
}
