package com.justiceserve.controller;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.CaseStatus;
import com.justiceserve.entity.VerificationStatus;
import com.justiceserve.service.CaseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * CaseController – Case filing and lifecycle management.
 * Base URL: /api/cases
 *
 * Angular Integration:
 *  POST   /api/cases                        → Citizen/Lawyer: File case form submission
 *  GET    /api/cases                        → Admin/Clerk/Judge: All cases list
 *  GET    /api/cases/{id}                   → Case detail page
 *  GET    /api/cases/citizen/{citizenId}    → Citizen: My cases list
 *  GET    /api/cases/lawyer/{lawyerId}      → Lawyer: My cases list
 *  GET    /api/cases/status/{status}        → Filter by status (dropdowns)
 *  PATCH  /api/cases/{id}/status?status=ACTIVE → Clerk/Admin: Update case status
 *  POST   /api/cases/{id}/documents         → Lawyer/Citizen: Upload evidence/petition
 *  GET    /api/cases/{id}/documents         → View case documents
 *  PATCH  /api/cases/{id}/documents/{docId}/verify?status=VERIFIED → Clerk: Verify doc
 */
@RestController
@RequestMapping("/api/cases")
@RequiredArgsConstructor
@Tag(name = "Case Management", description = "Case filing, tracking and document management")
public class CaseController {

    private final CaseService caseService;

    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN','LAWYER','CLERK','ADMIN')")
    @Operation(summary = "File a new case")
    public ResponseEntity<CaseResponse> fileCase(@Valid @RequestBody CaseRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(caseService.fileCase(request));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get all cases")
    public ResponseEntity<List<CaseResponse>> getAll() {
        return ResponseEntity.ok(caseService.getAllCases());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get case by ID")
    public ResponseEntity<CaseResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(caseService.getCaseById(id));
    }

    @GetMapping("/citizen/{citizenId}")
    @PreAuthorize("hasAnyRole('CITIZEN','LAWYER','ADMIN','CLERK')")
    @Operation(summary = "Get cases by citizen")
    public ResponseEntity<List<CaseResponse>> byCitizen(@PathVariable Long citizenId) {
        return ResponseEntity.ok(caseService.getCasesByCitizen(citizenId));
    }

    @GetMapping("/lawyer/{lawyerId}")
    @PreAuthorize("hasAnyRole('LAWYER','ADMIN','CLERK')")
    @Operation(summary = "Get cases by lawyer")
    public ResponseEntity<List<CaseResponse>> byLawyer(@PathVariable Long lawyerId) {
        return ResponseEntity.ok(caseService.getCasesByLawyer(lawyerId));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get cases by status")
    public ResponseEntity<List<CaseResponse>> byStatus(@PathVariable CaseStatus status) {
        return ResponseEntity.ok(caseService.getCasesByStatus(status));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE')")
    @Operation(summary = "Update case status")
    public ResponseEntity<CaseResponse> updateStatus(@PathVariable Long id, @RequestParam CaseStatus status) {
        return ResponseEntity.ok(caseService.updateCaseStatus(id, status));
    }

    @PostMapping("/{id}/documents")
    @PreAuthorize("hasAnyRole('CITIZEN','LAWYER','CLERK','ADMIN')")
    @Operation(summary = "Upload case document")
    public ResponseEntity<DocumentResponse> addDoc(@PathVariable Long id, @Valid @RequestBody DocumentRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(caseService.addDocument(id, req));
    }

    @GetMapping("/{id}/documents")
    @Operation(summary = "Get case documents")
    public ResponseEntity<List<DocumentResponse>> getDocs(@PathVariable Long id) {
        return ResponseEntity.ok(caseService.getDocuments(id));
    }

    @PatchMapping("/{caseId}/documents/{docId}/verify")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK')")
    @Operation(summary = "Verify case document")
    public ResponseEntity<DocumentResponse> verifyDoc(
            @PathVariable Long caseId, @PathVariable Long docId,
            @RequestParam VerificationStatus status) {
        return ResponseEntity.ok(caseService.verifyDocument(docId, status));
    }
}
