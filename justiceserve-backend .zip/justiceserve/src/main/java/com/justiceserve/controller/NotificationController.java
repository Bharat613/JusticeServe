package com.justiceserve.controller;

import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.NotificationResponse;
import com.justiceserve.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * NotificationController – In-app notification system.
 * Base URL: /api/notifications
 *
 * Angular Integration:
 *  GET    /api/notifications/user/{userId}        → Navbar bell: load user notifications
 *  GET    /api/notifications/user/{userId}/unread-count → Bell badge number
 *  PATCH  /api/notifications/{id}/read            → Mark read when user clicks
 *  POST   /api/notifications                      → Admin: send manual notification
 *
 *  Angular Polling: Call unread-count every 30 seconds for real-time badge updates.
 */
@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications", description = "In-app notification management")
public class NotificationController {

    private final NotificationService notificationService;

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Send manual notification (admin)")
    public ResponseEntity<NotificationResponse> send(@Valid @RequestBody NotificationRequest request) {
        return ResponseEntity.ok(notificationService.send(request));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all notifications for user", description = "Returns newest first. Angular uses this to populate notification dropdown.")
    public ResponseEntity<List<NotificationResponse>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.getByUser(userId));
    }

    @GetMapping("/user/{userId}/unread-count")
    @Operation(summary = "Get unread notification count", description = "Returns a number. Angular polls this for the bell badge.")
    public ResponseEntity<Long> unreadCount(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.countUnread(userId));
    }

    @PatchMapping("/{id}/read")
    @Operation(summary = "Mark notification as read")
    public ResponseEntity<NotificationResponse> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(notificationService.markRead(id));
    }
}
