package com.justiceserve.repository;

import com.justiceserve.entity.Case;
import com.justiceserve.entity.CaseStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CaseRepository extends JpaRepository<Case, Long> {
    /** All cases filed by a specific citizen. */
    List<Case> findByCitizenCitizenId(Long citizenId);
    /** All cases assigned to a specific lawyer. */
    List<Case> findByLawyerUserId(Long lawyerId);
    /** Filter cases by status (used by clerks/admins). */
    List<Case> findByStatus(CaseStatus status);
}
