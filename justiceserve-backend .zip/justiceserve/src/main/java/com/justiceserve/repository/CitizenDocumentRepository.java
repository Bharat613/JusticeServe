package com.justiceserve.repository;

import com.justiceserve.entity.CitizenDocument;
import com.justiceserve.entity.VerificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface CitizenDocumentRepository extends JpaRepository<CitizenDocument, Long> {
    List<CitizenDocument> findByCitizenCitizenId(Long citizenId);
    List<CitizenDocument> findByVerificationStatus(VerificationStatus status);
}
