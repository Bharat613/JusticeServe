package com.justiceserve.repository;

import com.justiceserve.entity.Role;
import com.justiceserve.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repository: UserRepository
 * Provides CRUD + custom queries for the users table.
 */
@Repository
public interface UserRepository extends JpaRepository<User, Long> {
    /** Used by Spring Security to load user during JWT authentication. */
    Optional<User> findByEmail(String email);
    /** Check for duplicate email on registration. */
    boolean existsByEmail(String email);
    /** Admin: list all users with a specific role. */
    List<User> findByRole(Role role);
}
