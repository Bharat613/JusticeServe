package com.justiceserve.repository;

import com.justiceserve.entity.Audit;
import com.justiceserve.entity.AuditStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AuditRepository extends JpaRepository<Audit, Long> {
    List<Audit> findByOfficerUserId(Long officerId);
    List<Audit> findByStatus(AuditStatus status);
}
