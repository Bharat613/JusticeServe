package com.justiceserve.repository;

import com.justiceserve.entity.Report;
import com.justiceserve.entity.ReportScope;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ReportRepository extends JpaRepository<Report, Long> {
    List<Report> findByScope(ReportScope scope);
    List<Report> findByGeneratedByUserId(Long userId);
}
