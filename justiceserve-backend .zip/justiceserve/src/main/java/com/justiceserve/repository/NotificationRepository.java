package com.justiceserve.repository;

import com.justiceserve.entity.Notification;
import com.justiceserve.entity.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findByUserUserIdOrderByCreatedDateDesc(Long userId);
    List<Notification> findByUserUserIdAndStatus(Long userId, NotificationStatus status);
    long countByUserUserIdAndStatus(Long userId, NotificationStatus status);
}
