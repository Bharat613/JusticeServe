package com.justiceserve.service.impl;

import com.justiceserve.dto.response.AuditLogResponse;
import com.justiceserve.entity.AuditLog;
import com.justiceserve.entity.User;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.AuditLogRepository;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * AuditLogServiceImpl
 * Writes immutable audit trail entries and retrieves them for admin review.
 */
@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository repo;
    private final UserRepository userRepo;

    /**
     * Inserts a new row into audit_logs.
     * Called internally by every service method that changes data.
     */
    @Override
    public void log(Long userId, String action, String resource) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));
        repo.save(AuditLog.builder().user(user).action(action).resource(resource).build());
    }

    /** Fetches all audit logs – admin/auditor only. */
    @Override
    public List<AuditLogResponse> getAllLogs() {
        return repo.findAll().stream().map(AuditLogResponse::from).toList();
    }

    /** Fetches audit logs for a specific user. */
    @Override
    public List<AuditLogResponse> getLogsByUser(Long userId) {
        return repo.findByUserUserIdOrderByTimestampDesc(userId)
                .stream().map(AuditLogResponse::from).toList();
    }
}
