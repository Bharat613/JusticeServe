package com.justiceserve.service.impl;

import com.justiceserve.dto.request.HearingRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.request.ProceedingRequest;
import com.justiceserve.dto.response.HearingResponse;
import com.justiceserve.dto.response.ProceedingResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.HearingService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * HearingServiceImpl – Hearing scheduling and proceedings management.
 *
 * DB tables affected: hearings, proceedings
 * Side effects: updates cases.status, sends notifications
 */
@Service
@RequiredArgsConstructor
public class HearingServiceImpl implements HearingService {

    private final HearingRepository hearingRepo;
    private final ProceedingRepository proceedingRepo;
    private final CaseRepository caseRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;

    /**
     * Inserts row into hearings table.
     * Updates associated case status to HEARING_SCHEDULED.
     * Notifies citizen and lawyer.
     */
    @Override
    @Transactional
    public HearingResponse scheduleHearing(HearingRequest req) {
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));

        Hearing h = Hearing.builder()
                .caseEntity(c).judge(judge).date(req.getDate()).time(req.getTime()).build();
        h = hearingRepo.save(h);

        // Update case status
        c.setStatus(CaseStatus.HEARING_SCHEDULED);
        caseRepo.save(c);

        // Notify citizen
        final Long hearingId = h.getHearingId();
        final String msg = "Hearing scheduled for case '" + c.getTitle() + "' on " + req.getDate() + " at " + req.getTime();
        notificationService.send(new NotificationRequest() {{
            setUserId(c.getCitizen().getUser().getUserId());
            setEntityId(hearingId); setMessage(msg); setCategory(NotificationCategory.HEARING);
        }});

        // Notify lawyer if assigned
        if (c.getLawyer() != null) {
            notificationService.send(new NotificationRequest() {{
                setUserId(c.getLawyer().getUserId());
                setEntityId(hearingId); setMessage(msg); setCategory(NotificationCategory.HEARING);
            }});
        }

        return HearingResponse.from(h);
    }

    @Override
    public HearingResponse getHearingById(Long id) {
        return HearingResponse.from(hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id)));
    }

    @Override
    public List<HearingResponse> getAllHearings() {
        return hearingRepo.findAll().stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByCase(Long caseId) {
        return hearingRepo.findByCaseEntityCaseId(caseId).stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByJudge(Long judgeId) {
        return hearingRepo.findByJudgeUserId(judgeId).stream().map(HearingResponse::from).toList();
    }

    /** Updates hearings.status column. */
    @Override
    public HearingResponse updateStatus(Long id, HearingStatus status) {
        Hearing h = hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id));
        h.setStatus(status);
        return HearingResponse.from(hearingRepo.save(h));
    }

    /** Inserts row into proceedings table for a hearing session. */
    @Override
    public ProceedingResponse addProceeding(ProceedingRequest req) {
        Hearing h = hearingRepo.findById(req.getHearingId())
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + req.getHearingId()));
        Proceeding p = Proceeding.builder()
                .hearing(h).notes(req.getNotes()).status(req.getStatus()).build();
        return ProceedingResponse.from(proceedingRepo.save(p));
    }

    @Override
    public List<ProceedingResponse> getProceedingsByHearing(Long hearingId) {
        return proceedingRepo.findByHearingHearingId(hearingId)
                .stream().map(ProceedingResponse::from).toList();
    }
}
