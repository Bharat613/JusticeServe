package com.justiceserve.service.impl;

import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.NotificationResponse;
import com.justiceserve.entity.Notification;
import com.justiceserve.entity.NotificationStatus;
import com.justiceserve.entity.User;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.NotificationRepository;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * NotificationServiceImpl – in-app notification delivery.
 * DB table: notifications
 * Called internally by Case, Hearing, Judgment services.
 */
@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository repo;
    private final UserRepository userRepo;

    /** Inserts notification row; called automatically by other services. */
    @Override
    public NotificationResponse send(NotificationRequest req) {
        User user = userRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + req.getUserId()));
        Notification n = Notification.builder()
                .user(user).entityId(req.getEntityId())
                .message(req.getMessage()).category(req.getCategory()).build();
        return NotificationResponse.from(repo.save(n));
    }

    /** Returns all notifications for the authenticated user, newest first. */
    @Override
    public List<NotificationResponse> getByUser(Long userId) {
        return repo.findByUserUserIdOrderByCreatedDateDesc(userId)
                .stream().map(NotificationResponse::from).toList();
    }

    /** Updates notifications.status → READ. Angular calls this when user opens notification. */
    @Override
    public NotificationResponse markRead(Long id) {
        Notification n = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id));
        n.setStatus(NotificationStatus.READ);
        return NotificationResponse.from(repo.save(n));
    }

    /** Returns count of UNREAD notifications – used for the badge number in Angular navbar. */
    @Override
    public long countUnread(Long userId) {
        return repo.countByUserUserIdAndStatus(userId, NotificationStatus.UNREAD);
    }
}
