package com.justiceserve.service;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.Role;
import com.justiceserve.entity.Status;
import java.util.List;

public interface UserService {
    List<UserResponse> getAllUsers();
    UserResponse getUserById(Long id);
    List<UserResponse> getUsersByRole(Role role);
    UserResponse updateUserStatus(Long id, Status status);
    void deleteUser(Long id);
}
