package com.justiceserve.service.impl;

import com.justiceserve.dto.request.LoginRequest;
import com.justiceserve.dto.request.RegisterRequest;
import com.justiceserve.dto.response.AuthResponse;
import com.justiceserve.entity.Status;
import com.justiceserve.entity.User;
import com.justiceserve.exception.BadRequestException;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.security.JwtUtils;
import com.justiceserve.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * AuthServiceImpl
 *
 * register(): Inserts new User into users table, returns JWT.
 * login():    Authenticates via Spring Security, returns JWT.
 *
 * Angular flow:
 *  1. POST /api/auth/login  → receives { token, userId, name, email, role }
 *  2. Store token in localStorage
 *  3. Add to every HTTP request: headers.set('Authorization', 'Bearer ' + token)
 */
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authManager;

    /**
     * Creates a new user account.
     * Validates unique email, hashes password, saves to DB, returns JWT.
     */
    @Override
    public AuthResponse register(RegisterRequest req) {
        if (userRepo.existsByEmail(req.getEmail()))
            throw new BadRequestException("Email already registered: " + req.getEmail());

        User user = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .password(encoder.encode(req.getPassword()))
                .role(req.getRole())
                .phone(req.getPhone())
                .status(Status.ACTIVE)
                .build();
        user = userRepo.save(user);
        String token = jwtUtils.generateToken(user);
        return new AuthResponse(token, user.getUserId(), user.getName(), user.getEmail(), user.getRole().name());
    }

    /**
     * Authenticates credentials against DB.
     * Throws 401 if invalid credentials (handled by Spring Security).
     */
    @Override
    public AuthResponse login(LoginRequest req) {
        authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        User user = userRepo.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("User not found"));
        String token = jwtUtils.generateToken(user);
        return new AuthResponse(token, user.getUserId(), user.getName(), user.getEmail(), user.getRole().name());
    }
}
