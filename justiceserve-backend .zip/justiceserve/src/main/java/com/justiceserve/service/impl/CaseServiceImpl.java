package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.CaseService;
import com.justiceserve.service.NotificationService;
import com.justiceserve.dto.request.NotificationRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * CaseServiceImpl – Core case lifecycle management.
 *
 * DB tables affected: cases, case_documents
 * Side effects: notifications sent on filing/status change
 */
@Service
@RequiredArgsConstructor
public class CaseServiceImpl implements CaseService {

    private final CaseRepository caseRepo;
    private final CitizenRepository citizenRepo;
    private final UserRepository userRepo;
    private final CaseDocumentRepository docRepo;
    private final NotificationService notificationService;

    /**
     * Inserts a new row into cases table with status=FILED.
     * Sends notification to clerk and citizen.
     */
    @Override
    @Transactional
    public CaseResponse fileCase(CaseRequest req) {
        Citizen citizen = citizenRepo.findById(req.getCitizenId())
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + req.getCitizenId()));

        User lawyer = null;
        if (req.getLawyerId() != null) {
            lawyer = userRepo.findById(req.getLawyerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Lawyer not found: " + req.getLawyerId()));
        }

        Case c = Case.builder()
                .citizen(citizen).lawyer(lawyer)
                .title(req.getTitle()).description(req.getDescription())
                .build();
        c = caseRepo.save(c);

        // Notify citizen that case was filed successfully
        notificationService.send(new NotificationRequest() {{
            setUserId(citizen.getUser().getUserId());
            setEntityId(c.getCaseId());
            setMessage("Your case '" + c.getTitle() + "' has been filed successfully. Case ID: " + c.getCaseId());
            setCategory(NotificationCategory.CASE);
        }});

        return CaseResponse.from(c);
    }

    @Override
    public CaseResponse getCaseById(Long id) {
        return CaseResponse.from(caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id)));
    }

    @Override
    public List<CaseResponse> getAllCases() {
        return caseRepo.findAll().stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByCitizen(Long citizenId) {
        return caseRepo.findByCitizenCitizenId(citizenId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByLawyer(Long lawyerId) {
        return caseRepo.findByLawyerUserId(lawyerId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByStatus(CaseStatus status) {
        return caseRepo.findByStatus(status).stream().map(CaseResponse::from).toList();
    }

    /**
     * Updates cases.status column.
     * Notifies citizen on status change.
     */
    @Override
    @Transactional
    public CaseResponse updateCaseStatus(Long id, CaseStatus status) {
        Case c = caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id));
        c.setStatus(status);
        c = caseRepo.save(c);

        notificationService.send(new NotificationRequest() {{
            setUserId(c.getCitizen().getUser().getUserId());
            setEntityId(c.getCaseId());
            setMessage("Case '" + c.getTitle() + "' status updated to: " + status.name());
            setCategory(NotificationCategory.CASE);
        }});

        return CaseResponse.from(c);
    }

    /** Inserts new row into case_documents table. */
    @Override
    public DocumentResponse addDocument(Long caseId, DocumentRequest req) {
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));
        CaseDocument doc = CaseDocument.builder()
                .caseEntity(c).docType(req.getDocType()).fileUri(req.getFileUri()).build();
        return DocumentResponse.fromCase(docRepo.save(doc));
    }

    @Override
    public List<DocumentResponse> getDocuments(Long caseId) {
        return docRepo.findByCaseEntityCaseId(caseId).stream().map(DocumentResponse::fromCase).toList();
    }

    /** Updates case_documents.verification_status. */
    @Override
    public DocumentResponse verifyDocument(Long docId, VerificationStatus status) {
        CaseDocument doc = docRepo.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(status);
        return DocumentResponse.fromCase(docRepo.save(doc));
    }
}
