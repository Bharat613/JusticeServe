package com.justiceserve.service;

import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.NotificationResponse;
import java.util.List;

public interface NotificationService {
    NotificationResponse send(NotificationRequest request);
    List<NotificationResponse> getByUser(Long userId);
    NotificationResponse markRead(Long id);
    long countUnread(Long userId);
}
