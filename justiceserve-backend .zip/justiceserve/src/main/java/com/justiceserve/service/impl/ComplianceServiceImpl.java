package com.justiceserve.service.impl;

import com.justiceserve.dto.request.AuditRequest;
import com.justiceserve.dto.request.ComplianceRecordRequest;
import com.justiceserve.dto.response.AuditResponse;
import com.justiceserve.dto.response.ComplianceRecordResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * ComplianceServiceImpl – compliance records and audit management.
 * DB tables: compliance_records, audits
 */
@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepo;
    private final AuditRepository auditRepo;
    private final UserRepository userRepo;

    @Override
    public ComplianceRecordResponse createRecord(ComplianceRecordRequest req) {
        ComplianceRecord r = ComplianceRecord.builder()
                .entityId(req.getEntityId()).type(req.getType())
                .result(req.getResult()).notes(req.getNotes()).build();
        return ComplianceRecordResponse.from(complianceRepo.save(r));
    }

    @Override
    public List<ComplianceRecordResponse> getAllRecords() {
        return complianceRepo.findAll().stream().map(ComplianceRecordResponse::from).toList();
    }

    @Override
    public ComplianceRecordResponse getRecordById(Long id) {
        return ComplianceRecordResponse.from(complianceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compliance record not found: " + id)));
    }

    /** Updates compliance_records row (result/notes). */
    @Override
    public ComplianceRecordResponse updateRecord(Long id, ComplianceRecordRequest req) {
        ComplianceRecord r = complianceRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compliance record not found: " + id));
        r.setResult(req.getResult()); r.setNotes(req.getNotes());
        return ComplianceRecordResponse.from(complianceRepo.save(r));
    }

    @Override
    public AuditResponse createAudit(AuditRequest req) {
        User officer = userRepo.findById(req.getOfficerId())
                .orElseThrow(() -> new ResourceNotFoundException("Officer not found: " + req.getOfficerId()));
        Audit a = Audit.builder().officer(officer).scope(req.getScope()).findings(req.getFindings()).build();
        return AuditResponse.from(auditRepo.save(a));
    }

    @Override
    public List<AuditResponse> getAllAudits() {
        return auditRepo.findAll().stream().map(AuditResponse::from).toList();
    }

    @Override
    public AuditResponse getAuditById(Long id) {
        return AuditResponse.from(auditRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Audit not found: " + id)));
    }

    /** Updates audits.status (OPEN → CLOSED etc.) */
    @Override
    public AuditResponse updateAuditStatus(Long id, AuditStatus status) {
        Audit a = auditRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Audit not found: " + id));
        a.setStatus(status);
        return AuditResponse.from(auditRepo.save(a));
    }
}
