package com.justiceserve.service;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.CaseStatus;
import com.justiceserve.entity.VerificationStatus;
import java.util.List;

public interface CaseService {
    CaseResponse fileCase(CaseRequest request);
    CaseResponse getCaseById(Long id);
    List<CaseResponse> getAllCases();
    List<CaseResponse> getCasesByCitizen(Long citizenId);
    List<CaseResponse> getCasesByLawyer(Long lawyerId);
    List<CaseResponse> getCasesByStatus(CaseStatus status);
    CaseResponse updateCaseStatus(Long id, CaseStatus status);
    DocumentResponse addDocument(Long caseId, DocumentRequest request);
    List<DocumentResponse> getDocuments(Long caseId);
    DocumentResponse verifyDocument(Long docId, VerificationStatus status);
}
