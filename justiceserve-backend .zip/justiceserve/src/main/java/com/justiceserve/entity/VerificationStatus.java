package com.justiceserve.entity;
public enum VerificationStatus { PENDING, VERIFIED, REJECTED }
