package com.justiceserve.entity;
public enum ReportScope { CASE, HEARING, JUDGMENT, COMPLIANCE }
