package com.justiceserve.entity;
public enum JudgmentStatus { DRAFT, FINAL }
