package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: Case
 * Table: cases
 *
 * Core entity of the system. Represents a legal case filed by a citizen,
 * optionally represented by a lawyer.
 *
 * DB Impact:
 *  - INSERT: POST /api/cases  → citizen or lawyer files a case
 *  - READ:   GET  /api/cases, /api/cases/{id}
 *  - UPDATE: PUT  /api/cases/{id}/status  → clerk/judge updates status
 *  - Cascades to: Hearing, Judgment, CourtOrder, CaseDocument, ComplianceRecord
 */
@Entity
@Table(name = "cases")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Case {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long caseId;

    /** Citizen who filed this case. FK → citizens.citizen_id */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "citizen_id", nullable = false)
    private Citizen citizen;

    /** Lawyer representing the citizen. FK → users.user_id (role=LAWYER). Nullable. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lawyer_id")
    private User lawyer;

    @Column(nullable = false, length = 200)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    private LocalDate filedDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 25)
    private CaseStatus status;

    @PrePersist
    public void prePersist() {
        this.filedDate = LocalDate.now();
        if (this.status == null) this.status = CaseStatus.FILED;
    }
}
