package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: Proceeding
 * Table: proceedings
 *
 * Notes and outcomes recorded during a hearing session.
 *
 * DB Impact:
 *  - INSERT: POST /api/hearings/{id}/proceedings  → judge/clerk records notes
 *  - READ:   GET  /api/hearings/{id}/proceedings
 */
@Entity
@Table(name = "proceedings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Proceeding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long proceedingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "hearing_id", nullable = false)
    private Hearing hearing;

    @Column(columnDefinition = "TEXT")
    private String notes;

    private LocalDate date;

    @Column(length = 20)
    private String status;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
        if (this.status == null) this.status = "IN_PROGRESS";
    }
}
