package com.justiceserve.entity;
public enum HearingStatus { SCHEDULED, IN_PROGRESS, COMPLETED, ADJOURNED, CANCELLED }
