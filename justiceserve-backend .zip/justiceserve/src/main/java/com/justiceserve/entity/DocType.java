package com.justiceserve.entity;
public enum DocType { PETITION, EVIDENCE, ORDER, ID_PROOF, LEGAL_DOC }
