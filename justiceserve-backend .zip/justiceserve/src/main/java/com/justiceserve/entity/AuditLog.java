package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entity: AuditLog
 * Table: audit_logs
 *
 * Immutable record of every significant action in the system.
 * Written by AuditLogService on any state-changing operation.
 *
 * DB Impact:
 *  - INSERT only: audit logs are never updated or deleted (immutable trail).
 *  - READ: admins/auditors query via /api/audit-logs
 */
@Entity
@Table(name = "audit_logs")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditLogId;

    /** The user who performed the action. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /** Short description of the action (e.g., "CASE_FILED", "HEARING_SCHEDULED"). */
    @Column(nullable = false, length = 100)
    private String action;

    /** The resource/entity affected (e.g., "Case:42"). */
    @Column(nullable = false, length = 150)
    private String resource;

    @Column(nullable = false)
    private LocalDateTime timestamp;

    @PrePersist
    public void prePersist() {
        this.timestamp = LocalDateTime.now();
    }
}
