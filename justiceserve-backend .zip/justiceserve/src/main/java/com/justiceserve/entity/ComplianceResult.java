package com.justiceserve.entity;
public enum ComplianceResult { COMPLIANT, NON_COMPLIANT, PENDING }
