package com.justiceserve.entity;
public enum CaseStatus { FILED, UNDER_REVIEW, ACTIVE, HEARING_SCHEDULED, JUDGMENT_PENDING, CLOSED, DISMISSED }
