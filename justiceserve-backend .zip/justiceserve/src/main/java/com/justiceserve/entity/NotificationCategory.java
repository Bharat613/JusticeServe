package com.justiceserve.entity;
public enum NotificationCategory { CASE, HEARING, JUDGMENT, COMPLIANCE }
