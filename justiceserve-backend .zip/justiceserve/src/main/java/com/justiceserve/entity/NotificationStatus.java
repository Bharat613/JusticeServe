package com.justiceserve.entity;
public enum NotificationStatus { UNREAD, READ }
