package com.justiceserve.entity;
public enum Status { ACTIVE, INACTIVE }
