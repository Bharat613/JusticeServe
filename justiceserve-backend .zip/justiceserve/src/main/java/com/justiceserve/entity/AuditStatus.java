package com.justiceserve.entity;
public enum AuditStatus { OPEN, CLOSED, REVIEW }
