package com.justiceserve.entity;
public enum OrderStatus { ACTIVE, SERVED, EXPIRED }
