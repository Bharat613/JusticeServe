package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: CitizenDocument
 * Table: citizen_documents
 *
 * Stores identity/legal documents uploaded by citizens.
 * Clerk verifies documents, updating verificationStatus.
 *
 * DB Impact:
 *  - INSERT: POST /api/citizens/{id}/documents
 *  - READ:   GET  /api/citizens/{id}/documents
 *  - UPDATE: PATCH /api/citizens/{id}/documents/{docId}/verify  (clerk action)
 */
@Entity
@Table(name = "citizen_documents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CitizenDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "citizen_id", nullable = false)
    private Citizen citizen;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private DocType docType;

    /** URI/path where the file is stored (e.g., /uploads/docs/file.pdf). */
    @Column(nullable = false, length = 300)
    private String fileUri;

    private LocalDate uploadedDate;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private VerificationStatus verificationStatus;

    @PrePersist
    public void prePersist() {
        this.uploadedDate = LocalDate.now();
        if (this.verificationStatus == null) this.verificationStatus = VerificationStatus.PENDING;
    }
}
