package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Entity: Hearing
 * Table: hearings
 *
 * A scheduled hearing for a case, assigned to a judge.
 *
 * DB Impact:
 *  - INSERT: POST /api/hearings  → clerk/judge schedules hearing, updates Case.status to HEARING_SCHEDULED
 *  - READ:   GET  /api/hearings, /api/hearings/case/{caseId}
 *  - UPDATE: PATCH /api/hearings/{id}/status  → judge updates outcome
 */
@Entity
@Table(name = "hearings")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Hearing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long hearingId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private Case caseEntity;

    /** FK → users.user_id where role=JUDGE */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "judge_id", nullable = false)
    private User judge;

    @Column(nullable = false)
    private LocalDate date;

    @Column(nullable = false)
    private LocalTime time;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private HearingStatus status;

    @PrePersist
    public void prePersist() {
        if (this.status == null) this.status = HearingStatus.SCHEDULED;
    }
}
