package com.justiceserve.entity;
public enum ComplianceType { CASE, HEARING, JUDGMENT }
