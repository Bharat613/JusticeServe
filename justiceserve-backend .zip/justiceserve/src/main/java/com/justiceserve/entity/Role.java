package com.justiceserve.entity;
public enum Role { CITIZEN, LAWYER, JUDGE, CLERK, ADMIN, COMPLIANCE, AUDITOR }
