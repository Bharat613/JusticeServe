package com.justiceserve.dto.response;

import com.justiceserve.entity.Report;
import com.justiceserve.entity.ReportScope;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ReportResponse {
    private Long reportId;
    private ReportScope scope;
    private String metrics;
    private LocalDate generatedDate;
    private Long generatedBy;

    public static ReportResponse from(Report r) {
        ReportResponse res = new ReportResponse();
        res.reportId = r.getReportId(); res.scope = r.getScope();
        res.metrics = r.getMetrics(); res.generatedDate = r.getGeneratedDate();
        if (r.getGeneratedBy() != null) res.generatedBy = r.getGeneratedBy().getUserId();
        return res;
    }
}
