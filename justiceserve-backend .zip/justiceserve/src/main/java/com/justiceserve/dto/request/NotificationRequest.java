package com.justiceserve.dto.request;

import com.justiceserve.entity.NotificationCategory;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class NotificationRequest {
    @NotNull private Long userId;
    private Long entityId;
    @NotBlank private String message;
    @NotNull private NotificationCategory category;
}
