package com.justiceserve.dto.request;

import com.justiceserve.entity.ReportScope;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ReportRequest {
    @NotNull private ReportScope scope;
    @NotNull private Long generatedBy;
}
