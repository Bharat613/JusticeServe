package com.justiceserve.dto.response;

import com.justiceserve.entity.Judgment;
import com.justiceserve.entity.JudgmentStatus;
import lombok.Data;
import java.time.LocalDate;

@Data
public class JudgmentResponse {
    private Long judgmentId;
    private Long caseId;
    private String caseTitle;
    private Long judgeId;
    private String judgeName;
    private String summary;
    private LocalDate date;
    private JudgmentStatus status;

    public static JudgmentResponse from(Judgment j) {
        JudgmentResponse r = new JudgmentResponse();
        r.judgmentId = j.getJudgmentId();
        r.caseId = j.getCaseEntity().getCaseId();
        r.caseTitle = j.getCaseEntity().getTitle();
        r.judgeId = j.getJudge().getUserId();
        r.judgeName = j.getJudge().getName();
        r.summary = j.getSummary(); r.date = j.getDate(); r.status = j.getStatus();
        return r;
    }
}
