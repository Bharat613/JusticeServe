package com.justiceserve.dto.request;

import com.justiceserve.entity.Role;
import jakarta.validation.constraints.*;
import lombok.Data;

/** POST /api/auth/register – Angular sends this JSON body. */
@Data
public class RegisterRequest {
    @NotBlank(message = "Name is required")
    private String name;

    @Email(message = "Valid email required")
    @NotBlank
    private String email;

    @NotBlank
    @Size(min = 6, message = "Password min 6 chars")
    private String password;

    @NotNull(message = "Role is required")
    private Role role;

    private String phone;
}
