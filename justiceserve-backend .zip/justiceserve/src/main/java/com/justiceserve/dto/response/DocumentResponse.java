package com.justiceserve.dto.response;

import com.justiceserve.entity.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class DocumentResponse {
    private Long documentId;
    private DocType docType;
    private String fileUri;
    private LocalDate uploadedDate;
    private VerificationStatus verificationStatus;

    public static DocumentResponse fromCase(CaseDocument d) {
        DocumentResponse r = new DocumentResponse();
        r.documentId = d.getDocumentId(); r.docType = d.getDocType();
        r.fileUri = d.getFileUri(); r.uploadedDate = d.getUploadedDate();
        r.verificationStatus = d.getVerificationStatus();
        return r;
    }

    public static DocumentResponse fromCitizen(CitizenDocument d) {
        DocumentResponse r = new DocumentResponse();
        r.documentId = d.getDocumentId(); r.docType = d.getDocType();
        r.fileUri = d.getFileUri(); r.uploadedDate = d.getUploadedDate();
        r.verificationStatus = d.getVerificationStatus();
        return r;
    }
}
