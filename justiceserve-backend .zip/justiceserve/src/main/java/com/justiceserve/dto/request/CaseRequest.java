package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/** POST /api/cases – Angular case filing form sends this. */
@Data
public class CaseRequest {
    @NotNull private Long citizenId;
    private Long lawyerId;           // optional
    @NotBlank private String title;
    private String description;
}
