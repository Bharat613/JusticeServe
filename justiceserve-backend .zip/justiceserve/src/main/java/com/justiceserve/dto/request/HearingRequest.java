package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

/** POST /api/hearings – Clerk schedules a hearing. */
@Data
public class HearingRequest {
    @NotNull private Long caseId;
    @NotNull private Long judgeId;
    @NotNull private LocalDate date;
    @NotNull private LocalTime time;
}
