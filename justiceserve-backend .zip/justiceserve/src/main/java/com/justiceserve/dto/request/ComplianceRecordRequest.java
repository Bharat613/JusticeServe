package com.justiceserve.dto.request;

import com.justiceserve.entity.ComplianceResult;
import com.justiceserve.entity.ComplianceType;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ComplianceRecordRequest {
    @NotNull private Long entityId;
    @NotNull private ComplianceType type;
    @NotNull private ComplianceResult result;
    private String notes;
}
