package com.justiceserve.dto.response;

import com.justiceserve.entity.Audit;
import com.justiceserve.entity.AuditStatus;
import lombok.Data;
import java.time.LocalDate;

@Data
public class AuditResponse {
    private Long auditId;
    private Long officerId;
    private String officerName;
    private String scope;
    private String findings;
    private LocalDate date;
    private AuditStatus status;

    public static AuditResponse from(Audit a) {
        AuditResponse r = new AuditResponse();
        r.auditId = a.getAuditId();
        r.officerId = a.getOfficer().getUserId();
        r.officerName = a.getOfficer().getName();
        r.scope = a.getScope(); r.findings = a.getFindings();
        r.date = a.getDate(); r.status = a.getStatus();
        return r;
    }
}
