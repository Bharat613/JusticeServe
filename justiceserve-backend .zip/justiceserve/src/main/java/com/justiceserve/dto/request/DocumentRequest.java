package com.justiceserve.dto.request;

import com.justiceserve.entity.DocType;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DocumentRequest {
    @NotNull private DocType docType;
    @NotBlank private String fileUri;
}
