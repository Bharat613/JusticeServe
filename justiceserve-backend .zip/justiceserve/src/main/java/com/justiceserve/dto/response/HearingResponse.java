package com.justiceserve.dto.response;

import com.justiceserve.entity.Hearing;
import com.justiceserve.entity.HearingStatus;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalTime;

@Data
public class HearingResponse {
    private Long hearingId;
    private Long caseId;
    private String caseTitle;
    private Long judgeId;
    private String judgeName;
    private LocalDate date;
    private LocalTime time;
    private HearingStatus status;

    public static HearingResponse from(Hearing h) {
        HearingResponse r = new HearingResponse();
        r.hearingId = h.getHearingId();
        r.caseId = h.getCaseEntity().getCaseId();
        r.caseTitle = h.getCaseEntity().getTitle();
        r.judgeId = h.getJudge().getUserId();
        r.judgeName = h.getJudge().getName();
        r.date = h.getDate(); r.time = h.getTime(); r.status = h.getStatus();
        return r;
    }
}
