package com.justiceserve.controller;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.Case;
import com.justiceserve.entity.CitizenDocument;
import com.justiceserve.service.CaseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/cases")
@RequiredArgsConstructor
public class CaseController {

    private final CaseService service;

    @PostMapping
    @PreAuthorize("hasAnyRole('CITIZEN','LAWYER','CLERK','ADMIN')")
    public ResponseEntity<CaseResponse> fileCase(@Valid @RequestBody CaseRequest req) {
        return ResponseEntity.ok(service.fileCase(req));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE','COMPLIANCE','AUDITOR')")
    public ResponseEntity<List<CaseResponse>> getAll() {
        return ResponseEntity.ok(service.getAllCases());
    }

    @GetMapping("/{id}")
    public ResponseEntity<CaseResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getCaseById(id));
    }

    @GetMapping("/citizen/{citizenId}")
    public ResponseEntity<List<CaseResponse>> getByCitizen(@PathVariable Long citizenId) {
        return ResponseEntity.ok(service.getCasesByCitizen(citizenId));
    }

    @GetMapping("/lawyer/{lawyerId}")
    public ResponseEntity<List<CaseResponse>> getByLawyer(@PathVariable Long lawyerId) {
        return ResponseEntity.ok(service.getCasesByLawyer(lawyerId));
    }

    @GetMapping("/status/{status}")
    public ResponseEntity<List<CaseResponse>> getByStatus(@PathVariable Case.CaseStatus status) {
        return ResponseEntity.ok(service.getCasesByStatus(status));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE')")
    public ResponseEntity<CaseResponse> updateStatus(@PathVariable Long id,
                                                      @RequestParam Case.CaseStatus status) {
        return ResponseEntity.ok(service.updateCaseStatus(id, status));
    }

    @PostMapping("/{id}/documents")
    public ResponseEntity<DocumentResponse> addDocument(@PathVariable Long id,
                                                         @Valid @RequestBody DocumentRequest req) {
        return ResponseEntity.ok(service.addDocument(id, req));
    }

    @GetMapping("/{id}/documents")
    public ResponseEntity<List<DocumentResponse>> getDocuments(@PathVariable Long id) {
        return ResponseEntity.ok(service.getDocuments(id));
    }

    @PatchMapping("/{caseId}/documents/{docId}/verify")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK')")
    public ResponseEntity<DocumentResponse> verifyDocument(@PathVariable Long docId,
                                                            @RequestParam CitizenDocument.VerificationStatus status) {
        return ResponseEntity.ok(service.verifyDocument(docId, status));
    }
}
