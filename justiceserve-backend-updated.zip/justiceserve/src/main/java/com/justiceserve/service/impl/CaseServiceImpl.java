package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.CaseService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * CaseServiceImpl – Core case lifecycle management.
 * DB tables: cases, case_documents
 * Side effects: notifications sent on filing/status change
 */
@Service
@RequiredArgsConstructor
public class CaseServiceImpl implements CaseService {

    private final CaseRepository caseRepo;
    private final CitizenRepository citizenRepo;
    private final UserRepository userRepo;
    private final CaseDocumentRepository docRepo;
    private final NotificationService notificationService;

    /**
     * Inserts new row into cases table with status=FILED.
     * Sends notification to citizen.
     */
    @Override
    @Transactional
    public CaseResponse fileCase(CaseRequest req) {
        Citizen citizen = citizenRepo.findById(req.getCitizenId())
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + req.getCitizenId()));
        User lawyer = null;
        if (req.getLawyerId() != null) {
            lawyer = userRepo.findById(req.getLawyerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Lawyer not found: " + req.getLawyerId()));
        }
        Case savedCase = caseRepo.save(Case.builder()
                .citizen(citizen).lawyer(lawyer)
                .title(req.getTitle()).description(req.getDescription()).build());

        notificationService.send(buildNotification(
                citizen.getUser().getUserId(), savedCase.getCaseId(),
                "Your case '" + savedCase.getTitle() + "' has been filed. Case ID: " + savedCase.getCaseId(),
                Notification.NotificationCategory.CASE));
        return CaseResponse.from(savedCase);
    }

    @Override
    public CaseResponse getCaseById(Long id) {
        return CaseResponse.from(caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id)));
    }

    @Override
    public List<CaseResponse> getAllCases() {
        return caseRepo.findAll().stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByCitizen(Long citizenId) {
        return caseRepo.findByCitizenCitizenId(citizenId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByLawyer(Long lawyerId) {
        return caseRepo.findByLawyerUserId(lawyerId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByStatus(Case.CaseStatus status) {
        return caseRepo.findByStatus(status).stream().map(CaseResponse::from).toList();
    }

    /**
     * Updates cases.status column. Notifies citizen on status change.
     */
    @Override
    @Transactional
    public CaseResponse updateCaseStatus(Long id, Case.CaseStatus status) {
        Case c = caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id));
        c.setStatus(status);
        Case updatedCase = caseRepo.save(c);
        notificationService.send(buildNotification(
                updatedCase.getCitizen().getUser().getUserId(), updatedCase.getCaseId(),
                "Case '" + updatedCase.getTitle() + "' status updated to: " + status.name(),
                Notification.NotificationCategory.CASE));
        return CaseResponse.from(updatedCase);
    }

    /** Inserts new row into case_documents table. */
    @Override
    public DocumentResponse addDocument(Long caseId, DocumentRequest req) {
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));
        CaseDocument doc = CaseDocument.builder()
                .caseEntity(c).docType(req.getDocType()).fileUri(req.getFileUri()).build();
        return DocumentResponse.fromCase(docRepo.save(doc));
    }

    @Override
    public List<DocumentResponse> getDocuments(Long caseId) {
        return docRepo.findByCaseEntityCaseId(caseId).stream().map(DocumentResponse::fromCase).toList();
    }

    /** Updates case_documents.verification_status. */
    @Override
    public DocumentResponse verifyDocument(Long docId, CitizenDocument.VerificationStatus status) {
        CaseDocument doc = docRepo.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(status);
        return DocumentResponse.fromCase(docRepo.save(doc));
    }

    private NotificationRequest buildNotification(Long userId, Long entityId,
                                                   String message, Notification.NotificationCategory category) {
        NotificationRequest n = new NotificationRequest();
        n.setUserId(userId); n.setEntityId(entityId);
        n.setMessage(message); n.setCategory(category);
        return n;
    }
}
