# ⚖️ JusticeServe – Legal Case & Court Management System

## Overview
JusticeServe is a full-stack Spring Boot backend for managing legal cases, hearings, judgments, compliance, and notifications in a court management system.

---

## Tech Stack
| Layer | Technology |
|---|---|
| Language | Java 21 |
| Framework | Spring Boot 3.2.5 |
| Security | Spring Security + JWT (JJWT 0.12.5) |
| ORM | Spring Data JPA + Hibernate |
| Database | MySQL 8+ |
| Validation | Jakarta Bean Validation |
| API Docs | Springdoc OpenAPI (Swagger UI) |
| Boilerplate | Lombok |

---

## Project Structure
```
src/main/java/com/justiceserve/
├── JusticeServeApplication.java       # Main entry point
├── config/
│   ├── SecurityConfig.java            # JWT + CORS + Role-based access
│   └── OpenApiConfig.java             # Swagger UI configuration
├── controller/                        # REST endpoints (all modules)
├── dto/
│   ├── request/                       # Input DTOs (form bodies from Angular)
│   └── response/                      # Output DTOs (JSON returned to Angular)
├── entity/                            # JPA entities (DB tables) + Enums
├── exception/                         # Custom exceptions + Global handler
├── repository/                        # Spring Data JPA interfaces
├── security/                          # JWT utils + filters
└── service/
    ├── *.java                         # Service interfaces
    └── impl/                          # Service implementations
```

---

## Database Setup
1. Install MySQL 8+
2. The app auto-creates the database on first run (`createDatabaseIfNotExist=true`)
3. Update `src/main/resources/application.properties`:
```properties
spring.datasource.username=YOUR_USERNAME
spring.datasource.password=YOUR_PASSWORD
```
4. First run: use `spring.jpa.hibernate.ddl-auto=create`
5. Subsequent runs: change to `update`

---

## Running the Application
```bash
# Clone and build
mvn clean install

# Run
mvn spring-boot:run

# Or build jar and run
mvn clean package
java -jar target/justiceserve-1.0.0.jar
```

Server starts at: `http://localhost:8080`

---

## Swagger UI
Visit: **http://localhost:8080/swagger-ui.html**

1. Use `POST /api/auth/login` to get a JWT token
2. Click **Authorize** (top right) → enter: `Bearer <your_token>`
3. All endpoints are now accessible

---

## API Endpoints Summary

### Authentication (`/api/auth`) – Public
| Method | URL | Description |
|---|---|---|
| POST | `/api/auth/register` | Register new user, returns JWT |
| POST | `/api/auth/login` | Login, returns JWT |

### Users (`/api/users`) – ADMIN
| Method | URL | Description |
|---|---|---|
| GET | `/api/users` | All users |
| GET | `/api/users/{id}` | User by ID |
| GET | `/api/users/role/{role}` | Users by role |
| PATCH | `/api/users/{id}/status` | Activate/deactivate user |
| DELETE | `/api/users/{id}` | Delete user |

### Citizens (`/api/citizens`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/citizens` | Create citizen profile |
| GET | `/api/citizens` | All citizens |
| GET | `/api/citizens/{id}` | Citizen by ID |
| GET | `/api/citizens/user/{userId}` | My Profile |
| PUT | `/api/citizens/{id}` | Update profile |
| POST | `/api/citizens/{id}/documents` | Upload document |
| GET | `/api/citizens/{id}/documents` | Get documents |
| PATCH | `/api/citizens/{cId}/documents/{dId}/verify` | Verify document |

### Cases (`/api/cases`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/cases` | File a case |
| GET | `/api/cases` | All cases |
| GET | `/api/cases/{id}` | Case detail |
| GET | `/api/cases/citizen/{id}` | Cases by citizen |
| GET | `/api/cases/lawyer/{id}` | Cases by lawyer |
| GET | `/api/cases/status/{status}` | Filter by status |
| PATCH | `/api/cases/{id}/status` | Update case status |
| POST | `/api/cases/{id}/documents` | Upload document |
| GET | `/api/cases/{id}/documents` | Case documents |
| PATCH | `/api/cases/{id}/documents/{dId}/verify` | Verify document |

### Hearings (`/api/hearings`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/hearings` | Schedule hearing |
| GET | `/api/hearings` | All hearings |
| GET | `/api/hearings/{id}` | Hearing detail |
| GET | `/api/hearings/case/{caseId}` | By case |
| GET | `/api/hearings/judge/{judgeId}` | By judge |
| PATCH | `/api/hearings/{id}/status` | Update status |
| POST | `/api/hearings/{id}/proceedings` | Add proceedings |
| GET | `/api/hearings/{id}/proceedings` | Get proceedings |

### Judgments (`/api/judgments`) + Orders (`/api/court-orders`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/judgments` | Record judgment |
| GET | `/api/judgments` | All judgments |
| GET | `/api/judgments/{id}` | Judgment detail |
| GET | `/api/judgments/case/{id}` | By case |
| PATCH | `/api/judgments/{id}/finalize` | Finalize (closes case) |
| POST | `/api/court-orders` | Issue order |
| GET | `/api/court-orders` | All orders |
| PATCH | `/api/court-orders/{id}/status` | Update order status |

### Compliance (`/api/compliance`) + Audits (`/api/audits`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/compliance` | Create compliance record |
| GET | `/api/compliance` | All records |
| PATCH | `/api/compliance/{id}` | Update record |
| POST | `/api/audits` | Create audit |
| GET | `/api/audits` | All audits |
| PATCH | `/api/audits/{id}/status` | Update audit status |

### Reports (`/api/reports`)
| Method | URL | Description |
|---|---|---|
| POST | `/api/reports/generate` | Generate report |
| GET | `/api/reports` | All reports |
| GET | `/api/reports/{id}` | Report detail |
| GET | `/api/reports/scope/{scope}` | By scope |

### Notifications (`/api/notifications`)
| Method | URL | Description |
|---|---|---|
| GET | `/api/notifications/user/{id}` | User notifications |
| GET | `/api/notifications/user/{id}/unread-count` | Unread count |
| PATCH | `/api/notifications/{id}/read` | Mark as read |

### Audit Logs (`/api/audit-logs`) – ADMIN/AUDITOR
| Method | URL | Description |
|---|---|---|
| GET | `/api/audit-logs` | All system logs |
| GET | `/api/audit-logs/user/{id}` | Logs by user |

---

## Role-Based Access Control (RBAC)
| Role | Access |
|---|---|
| CITIZEN | File cases, view own cases, upload documents |
| LAWYER | Manage assigned cases, upload documents |
| JUDGE | Manage hearings, record judgments, issue orders |
| CLERK | Schedule hearings, verify documents, manage records |
| ADMIN | Full system access |
| COMPLIANCE | Compliance records, audits, reports |
| AUDITOR | Read-only access to audits, reports, audit logs |

---

## Angular Frontend Integration Guide

### 1. Configure Angular HTTP Client
```typescript
// app.module.ts
import { HttpClientModule } from '@angular/common/http';
```

### 2. Auth Service (store token)
```typescript
// auth.service.ts
login(email: string, password: string) {
  return this.http.post<any>('http://localhost:8080/api/auth/login', {email, password})
    .pipe(tap(res => {
      localStorage.setItem('token', res.token);
      localStorage.setItem('role', res.role);
      localStorage.setItem('userId', res.userId);
    }));
}
```

### 3. HTTP Interceptor (auto-attach JWT)
```typescript
// jwt.interceptor.ts
intercept(req: HttpRequest<any>, next: HttpHandler) {
  const token = localStorage.getItem('token');
  if (token) {
    req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } });
  }
  return next.handle(req);
}
```

### 4. CORS
The backend allows `http://localhost:4200` by default.
Change `app.cors.allowed-origins` in `application.properties` for production.

### 5. Environment file
```typescript
// environments/environment.ts
export const environment = {
  apiUrl: 'http://localhost:8080/api'
};
```

---

## Entity Relationships
```
User ──────────────────── AuditLog (1:N)
User ──────────────────── Citizen  (1:1)
Citizen ────────────────── CitizenDocument (1:N)
Citizen ────────────────── Case (1:N)
User(Lawyer) ──────────── Case (N:1)
Case ───────────────────── CaseDocument (1:N)
Case ───────────────────── Hearing (1:N)
User(Judge) ────────────── Hearing (N:1)
Hearing ────────────────── Proceeding (1:N)
Case ───────────────────── Judgment (1:N)
User(Judge) ────────────── Judgment (N:1)
Case ───────────────────── CourtOrder (1:N)
User(Officer) ──────────── Audit (N:1)
User ───────────────────── Notification (1:N)
User ───────────────────── Report (N:1)
```

---

## File-by-File Description

| File | Purpose |
|---|---|
| `JusticeServeApplication.java` | Spring Boot entry point |
| `config/SecurityConfig.java` | JWT auth, CORS, role-based access rules |
| `config/OpenApiConfig.java` | Swagger UI setup with JWT support |
| `security/JwtUtils.java` | Generate + validate JWT tokens |
| `security/JwtAuthFilter.java` | Extract JWT from request, set SecurityContext |
| `security/UserDetailsServiceImpl.java` | Load user from DB for Spring Security |
| `entity/User.java` | Users table + Spring Security UserDetails |
| `entity/Citizen.java` | Citizen profile, 1:1 with User |
| `entity/Case.java` | Core legal case entity |
| `entity/Hearing.java` | Court hearing scheduling |
| `entity/Judgment.java` | Judge's judgment record |
| `entity/CourtOrder.java` | Court orders issued by judge |
| `entity/ComplianceRecord.java` | Policy compliance tracking |
| `entity/Audit.java` | Formal audit records |
| `entity/Report.java` | Analytics reports with JSON metrics |
| `entity/Notification.java` | In-app notifications |
| `entity/AuditLog.java` | Immutable system audit trail |
| `repository/*.java` | JPA repository interfaces with custom queries |
| `service/impl/AuthServiceImpl.java` | Register/login, JWT generation |
| `service/impl/CaseServiceImpl.java` | Case filing, status updates, notifications |
| `service/impl/HearingServiceImpl.java` | Hearing scheduling, proceeding notes |
| `service/impl/JudgmentServiceImpl.java` | Judgment + court orders, case closure |
| `service/impl/ComplianceServiceImpl.java` | Compliance records + audits |
| `service/impl/ReportServiceImpl.java` | Dynamic report generation |
| `service/impl/NotificationServiceImpl.java` | Send + read notifications |
| `service/impl/AuditLogServiceImpl.java` | Write/read audit trail |
| `controller/*.java` | REST endpoints with Swagger docs + role guards |
| `dto/request/*.java` | Input DTOs validated with @Valid |
| `dto/response/*.java` | Output DTOs (no passwords/sensitive data) |
| `exception/GlobalExceptionHandler.java` | Unified error response format |
| `application.properties` | DB, JWT, CORS, Swagger config |
