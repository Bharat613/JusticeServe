package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: Audit
 * Table: audits
 * Contains enum: AuditStatus
 *
 * Formal audits conducted by Compliance Officers or Government Auditors.
 * Tracks scope, findings, and resolution status.
 *
 * DB Impact:
 *  - INSERT: POST /api/audits
 *  - READ:   GET  /api/audits
 *  - UPDATE: PATCH /api/audits/{id}/status
 */
@Entity
@Table(name = "audits")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Audit {

    // ── Enum: AuditStatus ─────────────────────────────────────────
    /** Status of an audit record. */
    public enum AuditStatus {
        OPEN, CLOSED, REVIEW
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long auditId;

    /** FK → users.user_id where role=COMPLIANCE or AUDITOR */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "officer_id", nullable = false)
    private User officer;

    @Column(length = 200)
    private String scope;

    @Column(columnDefinition = "TEXT")
    private String findings;

    private LocalDate date;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private AuditStatus status;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
        if (this.status == null) this.status = AuditStatus.OPEN;
    }
}
