package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entity: Notification
 * Table: notifications
 * Contains enums: NotificationCategory, NotificationStatus
 *
 * In-app notifications sent to users about case/hearing/judgment/compliance events.
 * Created automatically by the service layer when relevant events occur.
 *
 * DB Impact:
 *  - INSERT: auto-created by service layer on case/hearing/judgment events
 *  - READ:   GET /api/notifications (user sees their own)
 *  - UPDATE: PATCH /api/notifications/{id}/read → mark as READ
 */
@Entity
@Table(name = "notifications")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Notification {

    // ── Enum: NotificationCategory ────────────────────────────────
    /** Category of notification sent to users. */
    public enum NotificationCategory {
        CASE, HEARING, JUDGMENT, COMPLIANCE
    }

    // ── Enum: NotificationStatus ──────────────────────────────────
    /** Whether the notification has been read by the user. */
    public enum NotificationStatus {
        UNREAD, READ
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long notificationId;

    /** FK → users.user_id — who receives this notification. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    /** ID of the related entity (caseId, hearingId etc.). */
    private Long entityId;

    @Column(columnDefinition = "TEXT")
    private String message;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private NotificationCategory category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private NotificationStatus status;

    private LocalDateTime createdDate;

    @PrePersist
    public void prePersist() {
        this.createdDate = LocalDateTime.now();
        if (this.status == null) this.status = NotificationStatus.UNREAD;
    }
}
