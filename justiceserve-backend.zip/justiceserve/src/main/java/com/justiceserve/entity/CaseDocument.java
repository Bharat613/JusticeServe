package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: CaseDocument
 * Table: case_documents
 *
 * Documents (petitions, evidence) attached to a case.
 * Uploaded by citizen/lawyer; verified by clerk.
 * Reuses DocType and VerificationStatus from CitizenDocument.
 *
 * DB Impact:
 *  - INSERT: POST /api/cases/{id}/documents
 *  - READ:   GET  /api/cases/{id}/documents
 *  - UPDATE: PATCH /api/cases/{id}/documents/{docId}/verify
 */
@Entity
@Table(name = "case_documents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CaseDocument {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long documentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private Case caseEntity;

    /** Uses DocType enum defined in CitizenDocument */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private CitizenDocument.DocType docType;

    @Column(nullable = false, length = 300)
    private String fileUri;

    private LocalDate uploadedDate;

    /** Uses VerificationStatus enum defined in CitizenDocument */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private CitizenDocument.VerificationStatus verificationStatus;

    @PrePersist
    public void prePersist() {
        this.uploadedDate = LocalDate.now();
        if (this.verificationStatus == null)
            this.verificationStatus = CitizenDocument.VerificationStatus.PENDING;
    }
}
