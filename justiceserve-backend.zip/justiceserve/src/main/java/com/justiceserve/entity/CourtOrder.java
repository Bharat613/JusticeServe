package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: CourtOrder
 * Table: court_orders
 * Contains enum: OrderStatus
 *
 * Court orders issued by a judge (stay orders, interim/final orders).
 * Linked to a case; compliance tracked via ComplianceRecord.
 *
 * DB Impact:
 *  - INSERT: POST /api/court-orders → judge issues an order
 *  - READ:   GET  /api/court-orders, /api/court-orders/case/{caseId}
 *  - UPDATE: PATCH /api/court-orders/{id}/status
 */
@Entity
@Table(name = "court_orders")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class CourtOrder {

    // ── Enum: OrderStatus ─────────────────────────────────────────
    /** Status of a court order lifecycle. */
    public enum OrderStatus {
        ACTIVE, SERVED, EXPIRED
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private Case caseEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "judge_id", nullable = false)
    private User judge;

    @Column(columnDefinition = "TEXT")
    private String description;

    private LocalDate date;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private OrderStatus status;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
        if (this.status == null) this.status = OrderStatus.ACTIVE;
    }
}
