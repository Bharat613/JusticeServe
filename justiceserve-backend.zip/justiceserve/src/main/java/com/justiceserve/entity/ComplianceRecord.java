package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: ComplianceRecord
 * Table: compliance_records
 * Contains enums: ComplianceType, ComplianceResult
 *
 * Tracks whether a Case, Hearing, or Judgment is compliant
 * with judicial policies. Created/updated by Compliance Officers.
 *
 * DB Impact:
 *  - INSERT: POST /api/compliance
 *  - READ:   GET  /api/compliance
 *  - UPDATE: PATCH /api/compliance/{id}
 */
@Entity
@Table(name = "compliance_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecord {

    // ── Enum: ComplianceType ──────────────────────────────────────
    /** Entity type being checked for compliance. */
    public enum ComplianceType {
        CASE, HEARING, JUDGMENT
    }

    // ── Enum: ComplianceResult ────────────────────────────────────
    /** Result of a compliance check. */
    public enum ComplianceResult {
        COMPLIANT, NON_COMPLIANT, PENDING
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long complianceId;

    /** ID of the entity being checked (caseId, hearingId, or judgmentId). */
    @Column(nullable = false)
    private Long entityId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private ComplianceType type;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 15)
    private ComplianceResult result;

    private LocalDate date;

    @Column(columnDefinition = "TEXT")
    private String notes;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
        if (this.result == null) this.result = ComplianceResult.PENDING;
    }
}
