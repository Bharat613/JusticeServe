package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import java.util.Collection;
import java.util.List;

/**
 * Entity: User
 * Table: users
 * Contains enums: Role, Status
 *
 * Central authentication entity. Every actor (Citizen, Lawyer, Judge etc.)
 * has one User record. Implements Spring Security UserDetails for JWT auth.
 *
 * DB Impact:
 *  - INSERT: POST /api/auth/register
 *  - READ:   loaded on every authenticated request via JwtAuthFilter
 *  - UPDATE: admin changes role/status via /api/admin/users/{id}
 */
@Entity
@Table(name = "users")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class User implements UserDetails {

    // ── Enum: Role ────────────────────────────────────────────────
    /** Roles assigned to users. Used for RBAC across all endpoints. */
    public enum Role {
        CITIZEN, LAWYER, JUDGE, CLERK, ADMIN, COMPLIANCE, AUDITOR
    }

    // ── Enum: Status ──────────────────────────────────────────────
    /** Active/inactive status. INACTIVE users cannot log in. */
    public enum Status {
        ACTIVE, INACTIVE
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(nullable = false, length = 100)
    private String name;

    /** Role determines which endpoints the user can access (RBAC). */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Column(length = 20)
    private String phone;

    /** BCrypt-hashed password – never returned in API responses. */
    @Column(nullable = false)
    private String password;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private Status status;

    // ── Spring Security methods ───────────────────────────────────
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override public String getUsername() { return email; }
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return status == Status.ACTIVE; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return status == Status.ACTIVE; }
}
