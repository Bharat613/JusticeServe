package com.justiceserve.entity;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

/**
 * Entity: Judgment
 * Table: judgments
 * Contains enum: JudgmentStatus
 *
 * Judgment delivered by a judge for a case.
 * On FINAL status, Case.status is updated to CLOSED.
 *
 * DB Impact:
 *  - INSERT: POST /api/judgments → judge records judgment (DRAFT)
 *  - READ:   GET  /api/judgments, /api/judgments/case/{caseId}
 *  - UPDATE: PATCH /api/judgments/{id}/finalize → moves to FINAL, closes case
 */
@Entity
@Table(name = "judgments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Judgment {

    // ── Enum: JudgmentStatus ──────────────────────────────────────
    /** Status of a judgment record. DRAFT → editable, FINAL → case closes. */
    public enum JudgmentStatus {
        DRAFT, FINAL
    }

    // ── Fields ────────────────────────────────────────────────────
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long judgmentId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "case_id", nullable = false)
    private Case caseEntity;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "judge_id", nullable = false)
    private User judge;

    @Column(columnDefinition = "TEXT")
    private String summary;

    private LocalDate date;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private JudgmentStatus status;

    @PrePersist
    public void prePersist() {
        this.date = LocalDate.now();
        if (this.status == null) this.status = JudgmentStatus.DRAFT;
    }
}
