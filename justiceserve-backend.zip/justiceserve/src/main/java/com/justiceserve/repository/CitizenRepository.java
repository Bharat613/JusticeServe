package com.justiceserve.repository;

import com.justiceserve.entity.Citizen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface CitizenRepository extends JpaRepository<Citizen, Long> {
    /** Find citizen profile linked to a user account. */
    Optional<Citizen> findByUserUserId(Long userId);
}
