package com.justiceserve.repository;

import com.justiceserve.entity.AuditLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {
    /** Fetch all audit entries for a specific user. */
    List<AuditLog> findByUserUserIdOrderByTimestampDesc(Long userId);
    /** Fetch audit logs for a specific resource (e.g., "Case:42"). */
    List<AuditLog> findByResourceContainingOrderByTimestampDesc(String resource);
}
