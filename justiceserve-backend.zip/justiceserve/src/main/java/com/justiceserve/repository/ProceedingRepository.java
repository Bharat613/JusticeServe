package com.justiceserve.repository;

import com.justiceserve.entity.Proceeding;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface ProceedingRepository extends JpaRepository<Proceeding, Long> {
    List<Proceeding> findByHearingHearingId(Long hearingId);
}
