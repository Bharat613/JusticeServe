package com.justiceserve.repository;

import com.justiceserve.entity.Hearing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.util.List;

@Repository
public interface HearingRepository extends JpaRepository<Hearing, Long> {
    List<Hearing> findByCaseEntityCaseId(Long caseId);
    List<Hearing> findByJudgeUserId(Long judgeId);
    List<Hearing> findByDate(LocalDate date);
    List<Hearing> findByStatus(Hearing.HearingStatus status);
}
