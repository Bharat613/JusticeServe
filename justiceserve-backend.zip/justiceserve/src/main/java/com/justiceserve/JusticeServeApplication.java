package com.justiceserve;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * JusticeServe – Legal Case & Court Management System
 * Entry point for the Spring Boot application.
 * Bootstraps all auto-configuration, component scanning, and JPA setup.
 */
@SpringBootApplication
public class JusticeServeApplication {
    public static void main(String[] args) {
        SpringApplication.run(JusticeServeApplication.class, args);
    }
}
