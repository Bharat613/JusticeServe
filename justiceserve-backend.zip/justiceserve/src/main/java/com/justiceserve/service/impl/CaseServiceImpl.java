package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.AuditLogService;
import com.justiceserve.service.CaseService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class CaseServiceImpl implements CaseService {

    private final CaseRepository caseRepo;
    private final CitizenRepository citizenRepo;
    private final UserRepository userRepo;
    private final CaseDocumentRepository docRepo;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;

    @Override
    @Transactional
    public CaseResponse fileCase(CaseRequest req) {
        log.info("Filing case for citizenId={}, lawyerId={}", req.getCitizenId(), req.getLawyerId());

        Citizen citizen = citizenRepo.findById(req.getCitizenId())
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + req.getCitizenId()));

        User lawyer = null;
        if (req.getLawyerId() != null) {
            lawyer = userRepo.findById(req.getLawyerId())
                    .orElseThrow(() -> new ResourceNotFoundException("Lawyer not found: " + req.getLawyerId()));
            log.info("Lawyer {} linked at filing time for citizenId={}", lawyer.getName(), req.getCitizenId());
        }

        Case savedCase = caseRepo.save(Case.builder()
                .citizen(citizen).lawyer(lawyer)
                .title(req.getTitle()).description(req.getDescription()).build());

        log.info("Case #{} filed: '{}'", savedCase.getCaseId(), savedCase.getTitle());

        // Audit log
        auditLogService.log(
                citizen.getUser().getUserId(),
                "CASE_FILED",
                "Case:" + savedCase.getCaseId() + " - " + savedCase.getTitle()
        );

        // Notifications
        if (lawyer != null) {
            // Citizen already chose a lawyer at filing
            notify(citizen.getUser().getUserId(), savedCase.getCaseId(),
                    "Your case \"" + savedCase.getTitle() + "\" (Case #" + savedCase.getCaseId() + ") has been filed successfully. " +
                    "Your lawyer " + lawyer.getName() + " has been linked. " +
                    "Please stay tuned for further hearing and process updates.",
                    Notification.NotificationCategory.CASE);

            notify(lawyer.getUserId(), savedCase.getCaseId(),
                    "Citizen " + citizen.getName() + " has filed Case #" + savedCase.getCaseId() +
                    ": \"" + savedCase.getTitle() + "\" and selected you as their lawyer. " +
                    "Please review all documents, analyse the case, and stay tuned for further hearings.",
                    Notification.NotificationCategory.CASE);

            auditLogService.log(lawyer.getUserId(), "LAWYER_LINKED_AT_FILING",
                    "Case:" + savedCase.getCaseId());
        } else {
            // Clerk will assign lawyer later
            notify(citizen.getUser().getUserId(), savedCase.getCaseId(),
                    "Your case \"" + savedCase.getTitle() + "\" (Case #" + savedCase.getCaseId() + ") has been filed successfully. " +
                    "The court clerk will review and assign a lawyer soon. Please stay tuned.",
                    Notification.NotificationCategory.CASE);
        }

        return CaseResponse.from(savedCase);
    }

    @Override
    public CaseResponse getCaseById(Long id) {
        return CaseResponse.from(caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id)));
    }

    @Override
    public List<CaseResponse> getAllCases() {
        return caseRepo.findAll().stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByCitizen(Long citizenId) {
        return caseRepo.findByCitizenCitizenId(citizenId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByLawyer(Long lawyerId) {
        return caseRepo.findByLawyerUserId(lawyerId).stream().map(CaseResponse::from).toList();
    }

    @Override
    public List<CaseResponse> getCasesByStatus(Case.CaseStatus status) {
        return caseRepo.findByStatus(status).stream().map(CaseResponse::from).toList();
    }

    @Override
    @Transactional
    public CaseResponse updateCaseStatus(Long id, Case.CaseStatus status) {
        log.info("Updating case #{} status to {}", id, status);
        Case c = caseRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + id));
        Case.CaseStatus oldStatus = c.getStatus();
        c.setStatus(status);
        Case updated = caseRepo.save(c);

        auditLogService.log(
                updated.getCitizen().getUser().getUserId(),
                "CASE_STATUS_UPDATED",
                "Case:" + id + " [" + oldStatus + " -> " + status + "]"
        );

        notify(updated.getCitizen().getUser().getUserId(), id,
                "Your case \"" + updated.getTitle() + "\" (Case #" + id + ") status has been updated to: " + status.name() + ".",
                Notification.NotificationCategory.CASE);

        if (updated.getLawyer() != null) {
            notify(updated.getLawyer().getUserId(), id,
                    "Case #" + id + " \"" + updated.getTitle() + "\" status updated to: " + status.name() + ".",
                    Notification.NotificationCategory.CASE);
        }
        return CaseResponse.from(updated);
    }

    @Override
    @Transactional
    public CaseResponse assignLawyer(Long caseId, Long lawyerId) {
        log.info("Assigning lawyerId={} to caseId={}", lawyerId, caseId);
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));
        User lawyer = userRepo.findById(lawyerId)
                .orElseThrow(() -> new ResourceNotFoundException("Lawyer not found: " + lawyerId));

        c.setLawyer(lawyer);
        Case saved = caseRepo.save(c);

        log.info("Lawyer {} assigned to Case #{}", lawyer.getName(), caseId);

        // Audit log — attributed to lawyer for traceability
        auditLogService.log(lawyer.getUserId(), "LAWYER_ASSIGNED",
                "Case:" + caseId + " - Lawyer: " + lawyer.getName());

        // Notify lawyer
        notify(lawyer.getUserId(), caseId,
                "You have been assigned as the lawyer for Case #" + caseId + ": \"" + saved.getTitle() + "\". " +
                "Citizen: " + saved.getCitizen().getName() + ". " +
                "Please review all case documents, analyse the matter, and stay tuned for hearing schedules and further updates.",
                Notification.NotificationCategory.CASE);

        // Notify citizen
        notify(saved.getCitizen().getUser().getUserId(), caseId,
                "Great news! Your case \"" + saved.getTitle() + "\" (Case #" + caseId + ") has been accepted by the court clerk. " +
                "Your assigned lawyer is " + lawyer.getName() + ". " +
                "Please stay tuned for further hearing and process updates.",
                Notification.NotificationCategory.CASE);

        return CaseResponse.from(saved);
    }

    @Override
    @Transactional
    public CaseResponse removeLawyer(Long caseId) {
        log.info("Removing lawyer from caseId={}", caseId);
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));

        String lawyerName = c.getLawyer() != null ? c.getLawyer().getName() : "Unknown";
        Long lawyerUserId = c.getLawyer() != null ? c.getLawyer().getUserId() : null;

        c.setLawyer(null);
        Case saved = caseRepo.save(c);

        log.info("Lawyer removed from Case #{}", caseId);

        // Audit log
        auditLogService.log(saved.getCitizen().getUser().getUserId(),
                "LAWYER_REMOVED",
                "Case:" + caseId + " - Removed lawyer: " + lawyerName);

        // Notify citizen
        notify(saved.getCitizen().getUser().getUserId(), caseId,
                "The lawyer " + lawyerName + " has been removed from your case \"" + saved.getTitle() + "\" (Case #" + caseId + "). " +
                "The court clerk will assign a new lawyer shortly.",
                Notification.NotificationCategory.CASE);

        // Notify removed lawyer
        if (lawyerUserId != null) {
            notify(lawyerUserId, caseId,
                    "You have been removed as the lawyer for Case #" + caseId + ": \"" + saved.getTitle() + "\". " +
                    "Please contact the court clerk for more information.",
                    Notification.NotificationCategory.CASE);
        }

        return CaseResponse.from(saved);
    }

    @Override
    @Transactional
    public CaseResponse assignJudge(Long caseId, Long judgeId) {
        log.info("Assigning judgeId={} to caseId={}", judgeId, caseId);
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));
        User judge = userRepo.findById(judgeId)
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + judgeId));

        c.setJudge(judge);
        Case saved = caseRepo.save(c);

        log.info("Judge {} assigned to Case #{}", judge.getName(), caseId);

        // Audit log
        auditLogService.log(judge.getUserId(), "JUDGE_ASSIGNED",
                "Case:" + caseId + " - Judge: " + judge.getName());

        // Notify judge
        notify(judge.getUserId(), caseId,
                "You have been assigned as the Judge for Case #" + caseId + ": \"" + saved.getTitle() + "\". " +
                "Citizen: " + saved.getCitizen().getName() +
                (saved.getLawyer() != null ? ", Lawyer: " + saved.getLawyer().getName() : "") + ". " +
                "Please review the case documents and schedule hearings as required.",
                Notification.NotificationCategory.CASE);

        // Notify citizen
        notify(saved.getCitizen().getUser().getUserId(), caseId,
                "A judge has been assigned to your case \"" + saved.getTitle() + "\" (Case #" + caseId + "). " +
                "Judge: " + judge.getName() + ". Your case will proceed to hearing scheduling soon.",
                Notification.NotificationCategory.CASE);

        // Notify lawyer if assigned
        if (saved.getLawyer() != null) {
            notify(saved.getLawyer().getUserId(), caseId,
                    "Judge " + judge.getName() + " has been assigned to Case #" + caseId + ": \"" + saved.getTitle() + "\". " +
                    "Please prepare your case arguments and stay updated on hearing schedules.",
                    Notification.NotificationCategory.CASE);
        }

        return CaseResponse.from(saved);
    }

    @Override
    public DocumentResponse addDocument(Long caseId, DocumentRequest req) {
        log.info("Adding document to caseId={}, docType={}", caseId, req.getDocType());
        Case c = caseRepo.findById(caseId)
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + caseId));
        CaseDocument doc = CaseDocument.builder()
                .caseEntity(c).docType(req.getDocType()).fileUri(req.getFileUri()).build();
        DocumentResponse saved = DocumentResponse.fromCase(docRepo.save(doc));

        auditLogService.log(c.getCitizen().getUser().getUserId(),
                "CASE_DOCUMENT_ADDED",
                "Case:" + caseId + " - DocType: " + req.getDocType());
        return saved;
    }

    @Override
    public List<DocumentResponse> getDocuments(Long caseId) {
        return docRepo.findByCaseEntityCaseId(caseId).stream().map(DocumentResponse::fromCase).toList();
    }

    @Override
    public DocumentResponse verifyDocument(Long docId, CitizenDocument.VerificationStatus status) {
        log.info("Verifying document docId={} status={}", docId, status);
        CaseDocument doc = docRepo.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(status);
        DocumentResponse saved = DocumentResponse.fromCase(docRepo.save(doc));

        auditLogService.log(doc.getCaseEntity().getCitizen().getUser().getUserId(),
                "CASE_DOCUMENT_" + status.name(),
                "CaseDocument:" + docId + " for Case:" + doc.getCaseEntity().getCaseId());
        return saved;
    }

    private void notify(Long userId, Long entityId, String message,
                        Notification.NotificationCategory category) {
        try {
            NotificationRequest n = new NotificationRequest();
            n.setUserId(userId); n.setEntityId(entityId);
            n.setMessage(message); n.setCategory(category);
            notificationService.send(n);
        } catch (Exception e) {
            log.warn("Failed to send notification to userId={}: {}", userId, e.getMessage());
        }
    }
}
