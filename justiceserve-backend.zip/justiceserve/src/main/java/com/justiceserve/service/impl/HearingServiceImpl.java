package com.justiceserve.service.impl;

import com.justiceserve.dto.request.HearingRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.request.ProceedingRequest;
import com.justiceserve.dto.response.HearingResponse;
import com.justiceserve.dto.response.ProceedingResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.AuditLogService;
import com.justiceserve.service.HearingService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class HearingServiceImpl implements HearingService {

    private final HearingRepository hearingRepo;
    private final ProceedingRepository proceedingRepo;
    private final CaseRepository caseRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;

    @Override
    @Transactional
    public HearingResponse scheduleHearing(HearingRequest req) {
        log.info("Scheduling hearing for caseId={}, judgeId={}, date={}", req.getCaseId(), req.getJudgeId(), req.getDate());

        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));

        Hearing saved = hearingRepo.save(Hearing.builder()
                .caseEntity(c).judge(judge).date(req.getDate()).time(req.getTime()).build());

        c.setStatus(Case.CaseStatus.HEARING_SCHEDULED);
        caseRepo.save(c);

        log.info("Hearing #{} scheduled for Case #{} on {}", saved.getHearingId(), c.getCaseId(), req.getDate());

        auditLogService.log(judge.getUserId(), "HEARING_SCHEDULED",
                "Hearing:" + saved.getHearingId() + " for Case:" + c.getCaseId() + " on " + req.getDate() + " at " + req.getTime());

        String msg = "A hearing has been scheduled for your case \"" + c.getTitle() + "\" (Case #" + c.getCaseId() + "). " +
                "Date: " + req.getDate() + " | Time: " + req.getTime() + " | Judge: " + judge.getName() + ". " +
                "Please be present or ensure your lawyer is present.";

        notify(c.getCitizen().getUser().getUserId(), saved.getHearingId(), msg, Notification.NotificationCategory.HEARING);

        if (c.getLawyer() != null) {
            notify(c.getLawyer().getUserId(), saved.getHearingId(),
                    "Hearing scheduled for Case #" + c.getCaseId() + " \"" + c.getTitle() + "\". " +
                    "Date: " + req.getDate() + " | Time: " + req.getTime() + " | Judge: " + judge.getName() + ". " +
                    "Please prepare your arguments and be present.",
                    Notification.NotificationCategory.HEARING);
        }

        return HearingResponse.from(saved);
    }

    @Override
    public HearingResponse getHearingById(Long id) {
        return HearingResponse.from(hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id)));
    }

    @Override
    public List<HearingResponse> getAllHearings() {
        return hearingRepo.findAll().stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByCase(Long caseId) {
        return hearingRepo.findByCaseEntityCaseId(caseId).stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByJudge(Long judgeId) {
        return hearingRepo.findByJudgeUserId(judgeId).stream().map(HearingResponse::from).toList();
    }

    @Override
    @Transactional
    public HearingResponse updateStatus(Long id, Hearing.HearingStatus status) {
        log.info("Updating hearing #{} status to {}", id, status);
        Hearing h = hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id));
        Hearing.HearingStatus old = h.getStatus();
        h.setStatus(status);
        Hearing saved = hearingRepo.save(h);

        auditLogService.log(saved.getJudge().getUserId(),
                "HEARING_STATUS_UPDATED",
                "Hearing:" + id + " [" + old + " -> " + status + "] for Case:" + saved.getCaseEntity().getCaseId());

        Case c = saved.getCaseEntity();
        notify(c.getCitizen().getUser().getUserId(), id,
                "Hearing #" + id + " for your case \"" + c.getTitle() + "\" status updated to: " + status.name() + ".",
                Notification.NotificationCategory.HEARING);

        return HearingResponse.from(saved);
    }

    @Override
    @Transactional
    public ProceedingResponse addProceeding(ProceedingRequest req) {
        log.info("Adding proceeding for hearingId={}", req.getHearingId());
        Hearing h = hearingRepo.findById(req.getHearingId())
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + req.getHearingId()));
        Proceeding p = Proceeding.builder().hearing(h).notes(req.getNotes()).status(req.getStatus()).build();
        Proceeding saved = proceedingRepo.save(p);

        auditLogService.log(h.getJudge().getUserId(),
                "PROCEEDING_ADDED",
                "Proceeding:" + saved.getProceedingId() + " for Hearing:" + req.getHearingId());
        return ProceedingResponse.from(saved);
    }

    @Override
    public List<ProceedingResponse> getProceedingsByHearing(Long hearingId) {
        return proceedingRepo.findByHearingHearingId(hearingId).stream().map(ProceedingResponse::from).toList();
    }

    private void notify(Long userId, Long entityId, String message, Notification.NotificationCategory category) {
        try {
            NotificationRequest n = new NotificationRequest();
            n.setUserId(userId); n.setEntityId(entityId);
            n.setMessage(message); n.setCategory(category);
            notificationService.send(n);
        } catch (Exception e) {
            log.warn("Failed to send notification to userId={}: {}", userId, e.getMessage());
        }
    }
}
