package com.justiceserve.service;

import com.justiceserve.dto.request.JudgmentRequest;
import com.justiceserve.dto.request.CourtOrderRequest;
import com.justiceserve.dto.response.JudgmentResponse;
import com.justiceserve.dto.response.CourtOrderResponse;
import com.justiceserve.entity.CourtOrder;
import java.util.List;

public interface JudgmentService {
    JudgmentResponse recordJudgment(JudgmentRequest request);
    JudgmentResponse getJudgmentById(Long id);
    List<JudgmentResponse> getAllJudgments();
    List<JudgmentResponse> getJudgmentsByCase(Long caseId);
    JudgmentResponse finalizeJudgment(Long id);
    CourtOrderResponse issueOrder(CourtOrderRequest request);
    CourtOrderResponse getOrderById(Long id);
    List<CourtOrderResponse> getAllOrders();
    List<CourtOrderResponse> getOrdersByCase(Long caseId);
    CourtOrderResponse updateOrderStatus(Long id, CourtOrder.OrderStatus status);
}
