package com.justiceserve.service;

import com.justiceserve.dto.request.CitizenRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CitizenResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.CitizenDocument;
import java.util.List;

public interface CitizenService {
    CitizenResponse createCitizen(CitizenRequest request);
    CitizenResponse getCitizenById(Long id);
    CitizenResponse getCitizenByUserId(Long userId);
    List<CitizenResponse> getAllCitizens();
    CitizenResponse updateCitizen(Long id, CitizenRequest request);
    DocumentResponse addDocument(Long citizenId, DocumentRequest request);
    List<DocumentResponse> getDocuments(Long citizenId);
    DocumentResponse verifyDocument(Long docId, CitizenDocument.VerificationStatus status);
}
