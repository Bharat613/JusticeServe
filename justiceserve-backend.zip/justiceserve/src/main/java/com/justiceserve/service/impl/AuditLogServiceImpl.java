package com.justiceserve.service.impl;

import com.justiceserve.dto.response.AuditLogResponse;
import com.justiceserve.entity.AuditLog;
import com.justiceserve.entity.User;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.AuditLogRepository;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository repo;
    private final UserRepository userRepo;

    @Override
    public void log(Long userId, String action, String resource) {
        try {
            User user = userRepo.findById(userId)
                    .orElseThrow(() -> new ResourceNotFoundException("User not found: " + userId));
            repo.save(AuditLog.builder().user(user).action(action).resource(resource).build());
            log.debug("AUDIT | userId={} | action={} | resource={}", userId, action, resource);
        } catch (Exception e) {
            log.error("Failed to write audit log — userId={}, action={}, resource={}: {}",
                    userId, action, resource, e.getMessage());
        }
    }

    @Override
    public List<AuditLogResponse> getAllLogs() {
        return repo.findAll().stream().map(AuditLogResponse::from).toList();
    }

    @Override
    public List<AuditLogResponse> getLogsByUser(Long userId) {
        return repo.findByUserUserIdOrderByTimestampDesc(userId)
                .stream().map(AuditLogResponse::from).toList();
    }
}
