package com.justiceserve.service.impl;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.User;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.service.AuditLogService;
import com.justiceserve.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository repo;
    private final AuditLogService auditLogService;

    @Override
    public List<UserResponse> getAllUsers() {
        return repo.findAll().stream().map(UserResponse::from).toList();
    }

    @Override
    public UserResponse getUserById(Long id) {
        return UserResponse.from(repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id)));
    }

    @Override
    public List<UserResponse> getUsersByRole(User.Role role) {
        return repo.findByRole(role).stream().map(UserResponse::from).toList();
    }

    @Override
    public UserResponse updateUserStatus(Long id, User.Status status) {
        log.info("Updating user #{} status to {}", id, status);
        var user = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        User.Status old = user.getStatus();
        user.setStatus(status);
        UserResponse saved = UserResponse.from(repo.save(user));

        auditLogService.log(id, "USER_STATUS_CHANGED",
                "User:" + id + " [" + old + " -> " + status + "]");
        return saved;
    }

    @Override
    public UserResponse updateUserRole(Long id, User.Role role) {
        log.info("Updating user #{} role to {}", id, role);
        var user = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        User.Role old = user.getRole();
        user.setRole(role);
        UserResponse saved = UserResponse.from(repo.save(user));

        log.info("User #{} role changed: {} -> {}", id, old, role);
        auditLogService.log(id, "USER_ROLE_CHANGED",
                "User:" + id + " - " + user.getName() + " [" + old + " -> " + role + "]");
        return saved;
    }

    @Override
    public void deleteUser(Long id) {
        log.info("Deleting user #{}", id);
        if (!repo.existsById(id)) throw new ResourceNotFoundException("User not found: " + id);
        auditLogService.log(id, "USER_DELETED", "User:" + id + " deleted");
        repo.deleteById(id);
    }
}
