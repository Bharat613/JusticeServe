package com.justiceserve.service.impl;

import com.justiceserve.dto.request.LoginRequest;
import com.justiceserve.dto.request.RegisterRequest;
import com.justiceserve.dto.response.AuthResponse;
import com.justiceserve.entity.User;
import com.justiceserve.exception.BadRequestException;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.security.JwtUtils;
import com.justiceserve.service.AuditLogService;
import com.justiceserve.service.AuthService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository userRepo;
    private final PasswordEncoder encoder;
    private final JwtUtils jwtUtils;
    private final AuthenticationManager authManager;
    private final AuditLogService auditLogService;

    @Override
    public AuthResponse register(RegisterRequest req) {
        log.info("Registration attempt for email={}", req.getEmail());

        if (userRepo.existsByEmail(req.getEmail()))
            throw new BadRequestException("Email already registered: " + req.getEmail());

        User user = User.builder()
                .name(req.getName())
                .email(req.getEmail())
                .password(encoder.encode(req.getPassword()))
                .role(User.Role.CITIZEN)
                .phone(req.getPhone())
                .status(User.Status.ACTIVE)
                .build();
        user = userRepo.save(user);

        log.info("User registered: id={}, name={}, email={}, role=CITIZEN", user.getUserId(), user.getName(), user.getEmail());

        auditLogService.log(user.getUserId(), "USER_REGISTERED",
                "User:" + user.getUserId() + " - " + user.getName() + " (" + user.getEmail() + ") registered as CITIZEN");

        String token = jwtUtils.generateToken(user);
        return new AuthResponse(token, user.getUserId(), user.getName(), user.getEmail(), user.getRole().name());
    }

    @Override
    public AuthResponse login(LoginRequest req) {
        log.info("Login attempt for email={}", req.getEmail());

        authManager.authenticate(new UsernamePasswordAuthenticationToken(req.getEmail(), req.getPassword()));
        User user = userRepo.findByEmail(req.getEmail())
                .orElseThrow(() -> new BadRequestException("User not found"));

        log.info("Login successful: userId={}, name={}, role={}", user.getUserId(), user.getName(), user.getRole());

        auditLogService.log(user.getUserId(), "USER_LOGIN",
                "User:" + user.getUserId() + " - " + user.getName() + " logged in with role=" + user.getRole());

        String token = jwtUtils.generateToken(user);
        return new AuthResponse(token, user.getUserId(), user.getName(), user.getEmail(), user.getRole().name());
    }
}
