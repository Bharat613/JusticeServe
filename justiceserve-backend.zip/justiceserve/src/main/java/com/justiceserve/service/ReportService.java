package com.justiceserve.service;

import com.justiceserve.dto.request.ReportRequest;
import com.justiceserve.dto.response.ReportResponse;
import com.justiceserve.entity.Report;
import java.util.List;

public interface ReportService {
    ReportResponse generateReport(ReportRequest request);
    List<ReportResponse> getAllReports();
    List<ReportResponse> getReportsByScope(Report.ReportScope scope);
    ReportResponse getReportById(Long id);
}
