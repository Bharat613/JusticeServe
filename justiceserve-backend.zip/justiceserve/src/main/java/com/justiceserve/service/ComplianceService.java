package com.justiceserve.service;

import com.justiceserve.dto.request.AuditRequest;
import com.justiceserve.dto.request.ComplianceRecordRequest;
import com.justiceserve.dto.response.AuditResponse;
import com.justiceserve.dto.response.ComplianceRecordResponse;
import com.justiceserve.entity.Audit;
import java.util.List;

public interface ComplianceService {
    ComplianceRecordResponse createRecord(ComplianceRecordRequest request);
    List<ComplianceRecordResponse> getAllRecords();
    ComplianceRecordResponse getRecordById(Long id);
    ComplianceRecordResponse updateRecord(Long id, ComplianceRecordRequest request);
    AuditResponse createAudit(AuditRequest request);
    List<AuditResponse> getAllAudits();
    AuditResponse getAuditById(Long id);
    AuditResponse updateAuditStatus(Long id, Audit.AuditStatus status);
}
