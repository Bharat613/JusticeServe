package com.justiceserve.service.impl;

import com.justiceserve.dto.request.ReportRequest;
import com.justiceserve.dto.response.ReportResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * ReportServiceImpl – analytics report generation.
 * DB table: reports
 * Queries multiple tables to compute metrics, stores as JSON string.
 */
@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final ReportRepository reportRepo;
    private final UserRepository userRepo;
    private final CaseRepository caseRepo;
    private final HearingRepository hearingRepo;
    private final JudgmentRepository judgmentRepo;
    private final ComplianceRecordRepository complianceRepo;

    /**
     * Generates a scoped analytics report.
     * Queries relevant tables and builds JSON metrics string.
     * Inserts the result into the reports table.
     */
    @Override
    public ReportResponse generateReport(ReportRequest req) {
        User user = userRepo.findById(req.getGeneratedBy())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + req.getGeneratedBy()));
        String metrics = buildMetrics(req.getScope());
        Report r = Report.builder().scope(req.getScope()).metrics(metrics).generatedBy(user).build();
        return ReportResponse.from(reportRepo.save(r));
    }

    /** Builds a JSON metrics string by querying the appropriate repository. */
    private String buildMetrics(Report.ReportScope scope) {
        return switch (scope) {
            case CASE -> {
                long total = caseRepo.count();
                long active = caseRepo.findByStatus(Case.CaseStatus.ACTIVE).size();
                long closed = caseRepo.findByStatus(Case.CaseStatus.CLOSED).size();
                yield String.format("{\"totalCases\":%d,\"activeCases\":%d,\"closedCases\":%d}", total, active, closed);
            }
            case HEARING -> {
                long total = hearingRepo.count();
                long completed = hearingRepo.findByStatus(Hearing.HearingStatus.COMPLETED).size();
                yield String.format("{\"totalHearings\":%d,\"completedHearings\":%d}", total, completed);
            }
            case JUDGMENT -> {
                long total = judgmentRepo.count();
                long finalized = judgmentRepo.findAll().stream()
                        .filter(j -> j.getStatus() == Judgment.JudgmentStatus.FINAL).count();
                yield String.format("{\"totalJudgments\":%d,\"finalizedJudgments\":%d}", total, finalized);
            }
            case COMPLIANCE -> {
                long total = complianceRepo.count();
                long compliant = complianceRepo.findAll().stream()
                        .filter(c -> c.getResult() == ComplianceRecord.ComplianceResult.COMPLIANT).count();
                yield String.format("{\"totalChecks\":%d,\"compliantCount\":%d}", total, compliant);
            }
        };
    }

    @Override
    public List<ReportResponse> getAllReports() {
        return reportRepo.findAll().stream().map(ReportResponse::from).toList();
    }

    @Override
    public List<ReportResponse> getReportsByScope(Report.ReportScope scope) {
        return reportRepo.findByScope(scope).stream().map(ReportResponse::from).toList();
    }

    @Override
    public ReportResponse getReportById(Long id) {
        return ReportResponse.from(reportRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found: " + id)));
    }
}
