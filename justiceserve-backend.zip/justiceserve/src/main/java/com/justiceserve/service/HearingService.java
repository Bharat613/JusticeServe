package com.justiceserve.service;

import com.justiceserve.dto.request.HearingRequest;
import com.justiceserve.dto.request.ProceedingRequest;
import com.justiceserve.dto.response.HearingResponse;
import com.justiceserve.dto.response.ProceedingResponse;
import com.justiceserve.entity.Hearing;
import java.util.List;

public interface HearingService {
    HearingResponse scheduleHearing(HearingRequest request);
    HearingResponse getHearingById(Long id);
    List<HearingResponse> getAllHearings();
    List<HearingResponse> getHearingsByCase(Long caseId);
    List<HearingResponse> getHearingsByJudge(Long judgeId);
    HearingResponse updateStatus(Long id, Hearing.HearingStatus status);
    ProceedingResponse addProceeding(ProceedingRequest request);
    List<ProceedingResponse> getProceedingsByHearing(Long hearingId);
}
