package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CourtOrderRequest;
import com.justiceserve.dto.request.JudgmentRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.CourtOrderResponse;
import com.justiceserve.dto.response.JudgmentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.AuditLogService;
import com.justiceserve.service.JudgmentService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class JudgmentServiceImpl implements JudgmentService {

    private final JudgmentRepository judgmentRepo;
    private final CourtOrderRepository orderRepo;
    private final CaseRepository caseRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;

    @Override
    @Transactional
    public JudgmentResponse recordJudgment(JudgmentRequest req) {
        log.info("Recording judgment for caseId={}, judgeId={}", req.getCaseId(), req.getJudgeId());
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));
        c.setStatus(Case.CaseStatus.JUDGMENT_PENDING);
        caseRepo.save(c);
        Judgment j = Judgment.builder().caseEntity(c).judge(judge).summary(req.getSummary()).build();
        Judgment saved = judgmentRepo.save(j);

        log.info("Judgment #{} recorded (DRAFT) for Case #{}", saved.getJudgmentId(), c.getCaseId());

        auditLogService.log(judge.getUserId(), "JUDGMENT_RECORDED",
                "Judgment:" + saved.getJudgmentId() + " (DRAFT) for Case:" + c.getCaseId());

        notify(c.getCitizen().getUser().getUserId(), saved.getJudgmentId(),
                "A judgment has been recorded (DRAFT) for your case \"" + c.getTitle() + "\" (Case #" + c.getCaseId() + "). " +
                "The final judgment will be announced shortly.",
                Notification.NotificationCategory.JUDGMENT);

        return JudgmentResponse.from(saved);
    }

    @Override
    public JudgmentResponse getJudgmentById(Long id) {
        return JudgmentResponse.from(judgmentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Judgment not found: " + id)));
    }

    @Override
    public List<JudgmentResponse> getAllJudgments() {
        return judgmentRepo.findAll().stream().map(JudgmentResponse::from).toList();
    }

    @Override
    public List<JudgmentResponse> getJudgmentsByCase(Long caseId) {
        return judgmentRepo.findByCaseEntityCaseId(caseId).stream().map(JudgmentResponse::from).toList();
    }

    @Override
    @Transactional
    public JudgmentResponse finalizeJudgment(Long id) {
        log.info("Finalizing judgment #{}", id);
        Judgment j = judgmentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Judgment not found: " + id));
        j.setStatus(Judgment.JudgmentStatus.FINAL);
        Judgment saved = judgmentRepo.save(j);
        Case c = saved.getCaseEntity();
        c.setStatus(Case.CaseStatus.CLOSED);
        caseRepo.save(c);

        log.info("Judgment #{} finalized. Case #{} CLOSED.", id, c.getCaseId());

        auditLogService.log(saved.getJudge().getUserId(), "JUDGMENT_FINALIZED",
                "Judgment:" + id + " FINAL — Case:" + c.getCaseId() + " CLOSED");

        notify(c.getCitizen().getUser().getUserId(), saved.getJudgmentId(),
                "The judgment for your case \"" + c.getTitle() + "\" (Case #" + c.getCaseId() + ") has been finalized. " +
                "Your case is now CLOSED. Please contact your lawyer or the court for the full judgment details.",
                Notification.NotificationCategory.JUDGMENT);

        if (c.getLawyer() != null) {
            notify(c.getLawyer().getUserId(), saved.getJudgmentId(),
                    "Judgment finalized for Case #" + c.getCaseId() + " \"" + c.getTitle() + "\". " +
                    "Case is now CLOSED. Please inform your client and proceed with post-judgment formalities.",
                    Notification.NotificationCategory.JUDGMENT);
        }

        if (c.getJudge() != null) {
            auditLogService.log(c.getJudge().getUserId(), "CASE_CLOSED",
                    "Case:" + c.getCaseId() + " closed via Judgment:" + id);
        }

        return JudgmentResponse.from(saved);
    }

    @Override
    @Transactional
    public CourtOrderResponse issueOrder(CourtOrderRequest req) {
        log.info("Issuing court order for caseId={}, judgeId={}", req.getCaseId(), req.getJudgeId());
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));
        CourtOrder o = CourtOrder.builder().caseEntity(c).judge(judge).description(req.getDescription()).build();
        CourtOrder saved = orderRepo.save(o);

        log.info("Court order #{} issued for Case #{}", saved.getOrderId(), c.getCaseId());

        auditLogService.log(judge.getUserId(), "COURT_ORDER_ISSUED",
                "CourtOrder:" + saved.getOrderId() + " for Case:" + c.getCaseId());

        notify(c.getCitizen().getUser().getUserId(), saved.getOrderId(),
                "A court order has been issued for your case \"" + c.getTitle() + "\" (Case #" + c.getCaseId() + "). " +
                "Please read the order details carefully and comply with the instructions.",
                Notification.NotificationCategory.JUDGMENT);

        if (c.getLawyer() != null) {
            notify(c.getLawyer().getUserId(), saved.getOrderId(),
                    "Court Order #" + saved.getOrderId() + " issued for Case #" + c.getCaseId() + ". " +
                    "Please review and ensure compliance.",
                    Notification.NotificationCategory.JUDGMENT);
        }

        return CourtOrderResponse.from(saved);
    }

    @Override
    public CourtOrderResponse getOrderById(Long id) {
        return CourtOrderResponse.from(orderRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id)));
    }

    @Override
    public List<CourtOrderResponse> getAllOrders() {
        return orderRepo.findAll().stream().map(CourtOrderResponse::from).toList();
    }

    @Override
    public List<CourtOrderResponse> getOrdersByCase(Long caseId) {
        return orderRepo.findByCaseEntityCaseId(caseId).stream().map(CourtOrderResponse::from).toList();
    }

    @Override
    @Transactional
    public CourtOrderResponse updateOrderStatus(Long id, CourtOrder.OrderStatus status) {
        log.info("Updating court order #{} status to {}", id, status);
        CourtOrder o = orderRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id));
        o.setStatus(status);
        CourtOrder saved = orderRepo.save(o);

        auditLogService.log(saved.getJudge().getUserId(), "COURT_ORDER_STATUS_UPDATED",
                "CourtOrder:" + id + " -> " + status);
        return CourtOrderResponse.from(saved);
    }

    private void notify(Long userId, Long entityId, String message, Notification.NotificationCategory category) {
        try {
            NotificationRequest n = new NotificationRequest();
            n.setUserId(userId); n.setEntityId(entityId);
            n.setMessage(message); n.setCategory(category);
            notificationService.send(n);
        } catch (Exception e) {
            log.warn("Failed to send notification to userId={}: {}", userId, e.getMessage());
        }
    }
}
