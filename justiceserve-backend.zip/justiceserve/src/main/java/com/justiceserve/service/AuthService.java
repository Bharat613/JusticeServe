package com.justiceserve.service;

import com.justiceserve.dto.request.LoginRequest;
import com.justiceserve.dto.request.RegisterRequest;
import com.justiceserve.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}
