package com.justiceserve.service;

import com.justiceserve.dto.response.AuditLogResponse;
import java.util.List;

public interface AuditLogService {
    void log(Long userId, String action, String resource);
    List<AuditLogResponse> getAllLogs();
    List<AuditLogResponse> getLogsByUser(Long userId);
}
