package com.justiceserve.controller;

import com.justiceserve.dto.request.AuditRequest;
import com.justiceserve.dto.request.ComplianceRecordRequest;
import com.justiceserve.dto.response.AuditResponse;
import com.justiceserve.dto.response.ComplianceRecordResponse;
import com.justiceserve.entity.Audit;
import com.justiceserve.service.ComplianceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class ComplianceController {

    private final ComplianceService service;

    @PostMapping("/compliance")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    public ResponseEntity<ComplianceRecordResponse> create(@Valid @RequestBody ComplianceRecordRequest req) {
        return ResponseEntity.ok(service.createRecord(req));
    }

    @GetMapping("/compliance")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','AUDITOR')")
    public ResponseEntity<List<ComplianceRecordResponse>> getAll() {
        return ResponseEntity.ok(service.getAllRecords());
    }

    @GetMapping("/compliance/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN','AUDITOR')")
    public ResponseEntity<ComplianceRecordResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getRecordById(id));
    }

    @PatchMapping("/compliance/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    public ResponseEntity<ComplianceRecordResponse> update(@PathVariable Long id,
                                                            @Valid @RequestBody ComplianceRecordRequest req) {
        return ResponseEntity.ok(service.updateRecord(id, req));
    }

    @PostMapping("/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    public ResponseEntity<AuditResponse> createAudit(@Valid @RequestBody AuditRequest req) {
        return ResponseEntity.ok(service.createAudit(req));
    }

    @GetMapping("/audits")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    public ResponseEntity<List<AuditResponse>> getAllAudits() {
        return ResponseEntity.ok(service.getAllAudits());
    }

    @GetMapping("/audits/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    public ResponseEntity<AuditResponse> getAuditById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getAuditById(id));
    }

    @PatchMapping("/audits/{id}/status")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    public ResponseEntity<AuditResponse> updateAuditStatus(@PathVariable Long id,
                                                            @RequestParam Audit.AuditStatus status) {
        return ResponseEntity.ok(service.updateAuditStatus(id, status));
    }
}
