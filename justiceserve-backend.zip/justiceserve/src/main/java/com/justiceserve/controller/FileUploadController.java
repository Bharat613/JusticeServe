package com.justiceserve.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.*;
import java.util.*;

/**
 * FileUploadController – handles real file upload and download.
 *
 * POST /api/files/upload   → upload a file, returns { fileUri, fileName, fileType, fileSize }
 * GET  /api/files/{fileName} → download / view a file
 *
 * Files are saved on the server in the directory set by app.upload.dir (default: uploads/).
 * The returned fileUri is stored in citizen_documents.file_uri / case_documents.file_uri.
 *
 * Allowed types: PDF, JPG, JPEG, PNG, DOC, DOCX
 * Max size: 10 MB (configured in application.properties)
 */
@Slf4j
@RestController
@RequestMapping("/api/files")
@Tag(name = "File Upload", description = "Upload and retrieve documents and images")
public class FileUploadController {

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    private static final Set<String> ALLOWED_TYPES = Set.of(
            "application/pdf",
            "image/jpeg", "image/jpg", "image/png",
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    );

    private static final Set<String> ALLOWED_EXTENSIONS = Set.of(
            "pdf", "jpg", "jpeg", "png", "doc", "docx"
    );

    /**
     * Upload a file.
     * Angular sends: multipart/form-data with field name "file"
     * Returns JSON: { fileUri, fileName, originalName, fileType, fileSize }
     */
    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @Operation(summary = "Upload a document or image",
               description = "Accepts PDF, JPG, PNG, DOC, DOCX. Max 10MB. Returns the fileUri to store.")
    public ResponseEntity<Map<String, Object>> upload(
            @RequestParam("file") MultipartFile file) throws IOException {

        // ── Validate ──────────────────────────────────────────
        if (file.isEmpty()) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File is empty. Please select a file to upload."));
        }

        String originalName = Objects.requireNonNull(file.getOriginalFilename(), "Filename missing");
        String extension = getExtension(originalName).toLowerCase();

        if (!ALLOWED_EXTENSIONS.contains(extension)) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "File type not allowed. Accepted: PDF, JPG, PNG, DOC, DOCX"));
        }

        String contentType = file.getContentType() != null ? file.getContentType() : "";
        if (!ALLOWED_TYPES.contains(contentType) && !contentType.contains("octet-stream")) {
            log.warn("Suspicious content type: {} for file: {}", contentType, originalName);
        }

        // ── Save file ─────────────────────────────────────────
        Path uploadPath = Paths.get(uploadDir).toAbsolutePath().normalize();
        Files.createDirectories(uploadPath);

        // Unique filename: timestamp_uuid.ext  (prevents overwriting)
        String uniqueName = System.currentTimeMillis() + "_" +
                UUID.randomUUID().toString().replace("-", "").substring(0, 8) +
                "." + extension;

        Path targetPath = uploadPath.resolve(uniqueName);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        // The fileUri stored in DB — frontend fetches via GET /api/files/{fileName}
        String fileUri = "/api/files/" + uniqueName;

        log.info("File uploaded: {} → {} ({} bytes)", originalName, uniqueName, file.getSize());

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("fileUri",      fileUri);
        response.put("fileName",     uniqueName);
        response.put("originalName", originalName);
        response.put("fileType",     contentType);
        response.put("fileSize",     file.getSize());
        return ResponseEntity.ok(response);
    }

    /**
     * Download / view a file by its stored filename.
     * Angular uses this as the href for document links.
     */
    @GetMapping("/{fileName:.+}")
    @Operation(summary = "Download or view a file")
    public ResponseEntity<Resource> download(@PathVariable String fileName) {
        try {
            Path filePath = Paths.get(uploadDir).toAbsolutePath().normalize().resolve(fileName);
            Resource resource = new UrlResource(filePath.toUri());

            if (!resource.exists() || !resource.isReadable()) {
                return ResponseEntity.notFound().build();
            }

            String contentType = determineContentType(fileName);
            // inline = view in browser; attachment = force download
            String disposition = isViewable(fileName) ? "inline" : "attachment";

            return ResponseEntity.ok()
                    .contentType(MediaType.parseMediaType(contentType))
                    .header(HttpHeaders.CONTENT_DISPOSITION,
                            disposition + "; filename=\"" + resource.getFilename() + "\"")
                    .body(resource);

        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // ── Helpers ───────────────────────────────────────────────────
    private String getExtension(String filename) {
        int dot = filename.lastIndexOf('.');
        return dot > 0 ? filename.substring(dot + 1) : "";
    }

    private String determineContentType(String fileName) {
        String ext = getExtension(fileName).toLowerCase();
        return switch (ext) {
            case "pdf"  -> "application/pdf";
            case "png"  -> "image/png";
            case "jpg",
                 "jpeg" -> "image/jpeg";
            case "doc"  -> "application/msword";
            case "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            default     -> "application/octet-stream";
        };
    }

    private boolean isViewable(String fileName) {
        String ext = getExtension(fileName).toLowerCase();
        return Set.of("pdf", "jpg", "jpeg", "png").contains(ext);
    }
}
