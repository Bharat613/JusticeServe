package com.justiceserve.controller;

import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.NotificationResponse;
import com.justiceserve.service.NotificationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

/**
 * NotificationController – In-app notification system.
 * Base URL: /api/notifications
 *
 * Angular Integration:
 *  POST   /api/notifications                           → Send notification (any authenticated user)
 *  GET    /api/notifications/user/{userId}             → Load user notifications
 *  GET    /api/notifications/user/{userId}/unread-count → Bell badge number
 *  PATCH  /api/notifications/{id}/read                 → Mark single read
 *  PATCH  /api/notifications/user/{userId}/read-all    → Mark all read
 */
@RestController
@RequestMapping("/api/notifications")
@RequiredArgsConstructor
@Tag(name = "Notifications", description = "In-app notification management")
public class NotificationController {

    private final NotificationService notificationService;

    /** Send a notification — open to all authenticated roles so services/frontend can trigger. */
    @PostMapping
    @Operation(summary = "Send notification")
    public ResponseEntity<NotificationResponse> send(@Valid @RequestBody NotificationRequest request) {
        return ResponseEntity.ok(notificationService.send(request));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all notifications for user")
    public ResponseEntity<List<NotificationResponse>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.getByUser(userId));
    }

    @GetMapping("/user/{userId}/unread-count")
    @Operation(summary = "Get unread notification count")
    public ResponseEntity<Long> unreadCount(@PathVariable Long userId) {
        return ResponseEntity.ok(notificationService.countUnread(userId));
    }

    @PatchMapping("/{id}/read")
    @Operation(summary = "Mark notification as read")
    public ResponseEntity<NotificationResponse> markRead(@PathVariable Long id) {
        return ResponseEntity.ok(notificationService.markRead(id));
    }

    @PatchMapping("/user/{userId}/read-all")
    @Operation(summary = "Mark all notifications as read for a user")
    public ResponseEntity<Void> markAllRead(@PathVariable Long userId) {
        notificationService.markAllRead(userId);
        return ResponseEntity.ok().build();
    }
}
