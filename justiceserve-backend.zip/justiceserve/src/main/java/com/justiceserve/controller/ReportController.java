package com.justiceserve.controller;

import com.justiceserve.dto.request.ReportRequest;
import com.justiceserve.dto.response.ReportResponse;
import com.justiceserve.entity.Report;
import com.justiceserve.service.ReportService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
public class ReportController {

    private final ReportService service;

    @PostMapping("/generate")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    public ResponseEntity<ReportResponse> generate(@Valid @RequestBody ReportRequest req) {
        return ResponseEntity.ok(service.generateReport(req));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    public ResponseEntity<List<ReportResponse>> getAll() {
        return ResponseEntity.ok(service.getAllReports());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    public ResponseEntity<ReportResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getReportById(id));
    }

    @GetMapping("/scope/{scope}")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE','AUDITOR')")
    public ResponseEntity<List<ReportResponse>> getByScope(@PathVariable Report.ReportScope scope) {
        return ResponseEntity.ok(service.getReportsByScope(scope));
    }
}
