package com.justiceserve.controller;

import com.justiceserve.dto.request.CourtOrderRequest;
import com.justiceserve.dto.request.JudgmentRequest;
import com.justiceserve.dto.response.CourtOrderResponse;
import com.justiceserve.dto.response.JudgmentResponse;
import com.justiceserve.entity.CourtOrder;
import com.justiceserve.service.JudgmentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class JudgmentController {

    private final JudgmentService service;

    @PostMapping("/judgments")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    public ResponseEntity<JudgmentResponse> record(@Valid @RequestBody JudgmentRequest req) {
        return ResponseEntity.ok(service.recordJudgment(req));
    }

    @GetMapping("/judgments")
    public ResponseEntity<List<JudgmentResponse>> getAll() {
        return ResponseEntity.ok(service.getAllJudgments());
    }

    @GetMapping("/judgments/{id}")
    public ResponseEntity<JudgmentResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getJudgmentById(id));
    }

    @GetMapping("/judgments/case/{caseId}")
    public ResponseEntity<List<JudgmentResponse>> getByCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(service.getJudgmentsByCase(caseId));
    }

    @PatchMapping("/judgments/{id}/finalize")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    public ResponseEntity<JudgmentResponse> finalize(@PathVariable Long id) {
        return ResponseEntity.ok(service.finalizeJudgment(id));
    }

    @PostMapping("/court-orders")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    public ResponseEntity<CourtOrderResponse> issueOrder(@Valid @RequestBody CourtOrderRequest req) {
        return ResponseEntity.ok(service.issueOrder(req));
    }

    @GetMapping("/court-orders")
    public ResponseEntity<List<CourtOrderResponse>> getAllOrders() {
        return ResponseEntity.ok(service.getAllOrders());
    }

    @GetMapping("/court-orders/{id}")
    public ResponseEntity<CourtOrderResponse> getOrderById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getOrderById(id));
    }

    @GetMapping("/court-orders/case/{caseId}")
    public ResponseEntity<List<CourtOrderResponse>> getOrdersByCase(@PathVariable Long caseId) {
        return ResponseEntity.ok(service.getOrdersByCase(caseId));
    }

    @PatchMapping("/court-orders/{id}/status")
    @PreAuthorize("hasAnyRole('JUDGE','ADMIN')")
    public ResponseEntity<CourtOrderResponse> updateOrderStatus(@PathVariable Long id,
                                                                 @RequestParam CourtOrder.OrderStatus status) {
        return ResponseEntity.ok(service.updateOrderStatus(id, status));
    }
}
