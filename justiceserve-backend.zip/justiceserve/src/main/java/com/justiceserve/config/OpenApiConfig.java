package com.justiceserve.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.Components;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * OpenApiConfig – Swagger/OpenAPI configuration.
 *
 * Access Swagger UI at: http://localhost:8080/swagger-ui.html
 * After login, click "Authorize" and paste: Bearer <your_token>
 */
@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI justiceServeOpenAPI() {
        return new OpenAPI()
            .info(new Info()
                .title("JusticeServe API")
                .description("Legal Case & Court Management System – Full REST API. " +
                    "Login via POST /api/auth/login to get a JWT token, then click Authorize above.")
                .version("1.0.0"))
            .addSecurityItem(new SecurityRequirement().addList("Bearer Authentication"))
            .components(new Components().addSecuritySchemes("Bearer Authentication",
                new SecurityScheme()
                    .type(SecurityScheme.Type.HTTP)
                    .scheme("bearer")
                    .bearerFormat("JWT")));
    }
}
