package com.justiceserve.exception;

/**
 * Thrown when a user attempts an action they are not permitted.
 * Maps to HTTP 403 via GlobalExceptionHandler.
 */
public class UnauthorizedException extends RuntimeException {
    public UnauthorizedException(String message) {
        super(message);
    }
}
