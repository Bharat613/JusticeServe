package com.justiceserve.exception;

/**
 * Thrown when a requested entity (Case, User, Hearing, etc.) is not found in DB.
 * Maps to HTTP 404 via GlobalExceptionHandler.
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
