package com.justiceserve.exception;

/**
 * Thrown for invalid business logic (e.g., filing case for inactive citizen).
 * Maps to HTTP 400 via GlobalExceptionHandler.
 */
public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) {
        super(message);
    }
}
