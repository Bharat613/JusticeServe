package com.justiceserve.dto.request;

import com.justiceserve.entity.ComplianceRecord;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ComplianceRecordRequest {
    @NotNull private Long entityId;
    @NotNull private ComplianceRecord.ComplianceType type;
    @NotNull private ComplianceRecord.ComplianceResult result;
    private String notes;
}
