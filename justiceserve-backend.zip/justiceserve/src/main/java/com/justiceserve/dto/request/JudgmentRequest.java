package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/** POST /api/judgments – Judge records a judgment. */
@Data
public class JudgmentRequest {
    @NotNull private Long caseId;
    @NotNull private Long judgeId;
    @NotBlank private String summary;
}
