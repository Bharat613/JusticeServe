package com.justiceserve.dto.response;

import com.justiceserve.entity.Case;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CaseResponse {
    private Long caseId;
    private Long citizenId;
    private String citizenName;
    private Long lawyerId;
    private String lawyerName;
    private Long judgeId;
    private String judgeName;
    private String title;
    private String description;
    private LocalDate filedDate;
    private Case.CaseStatus status;

    public static CaseResponse from(Case c) {
        CaseResponse r = new CaseResponse();
        r.caseId = c.getCaseId();
        r.citizenId = c.getCitizen().getCitizenId();
        r.citizenName = c.getCitizen().getName();
        if (c.getLawyer() != null) { r.lawyerId = c.getLawyer().getUserId(); r.lawyerName = c.getLawyer().getName(); }
        if (c.getJudge() != null) { r.judgeId = c.getJudge().getUserId(); r.judgeName = c.getJudge().getName(); }
        r.title = c.getTitle(); r.description = c.getDescription();
        r.filedDate = c.getFiledDate(); r.status = c.getStatus();
        return r;
    }
}
