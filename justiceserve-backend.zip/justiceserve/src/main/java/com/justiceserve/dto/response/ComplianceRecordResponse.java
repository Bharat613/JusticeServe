package com.justiceserve.dto.response;

import com.justiceserve.entity.ComplianceRecord;
import lombok.Data;
import java.time.LocalDate;

@Data
public class ComplianceRecordResponse {
    private Long complianceId;
    private Long entityId;
    private ComplianceRecord.ComplianceType type;
    private ComplianceRecord.ComplianceResult result;
    private LocalDate date;
    private String notes;

    public static ComplianceRecordResponse from(ComplianceRecord c) {
        ComplianceRecordResponse r = new ComplianceRecordResponse();
        r.complianceId = c.getComplianceId(); r.entityId = c.getEntityId();
        r.type = c.getType(); r.result = c.getResult();
        r.date = c.getDate(); r.notes = c.getNotes();
        return r;
    }
}
