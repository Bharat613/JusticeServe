package com.justiceserve.dto.response;

import com.justiceserve.entity.CourtOrder;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CourtOrderResponse {
    private Long orderId;
    private Long caseId;
    private String caseTitle;
    private Long judgeId;
    private String judgeName;
    private String description;
    private LocalDate date;
    private CourtOrder.OrderStatus status;

    public static CourtOrderResponse from(CourtOrder o) {
        CourtOrderResponse r = new CourtOrderResponse();
        r.orderId = o.getOrderId();
        r.caseId = o.getCaseEntity().getCaseId();
        r.caseTitle = o.getCaseEntity().getTitle();
        r.judgeId = o.getJudge().getUserId();
        r.judgeName = o.getJudge().getName();
        r.description = o.getDescription(); r.date = o.getDate(); r.status = o.getStatus();
        return r;
    }
}
