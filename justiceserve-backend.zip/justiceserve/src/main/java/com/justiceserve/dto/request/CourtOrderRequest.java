package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CourtOrderRequest {
    @NotNull private Long caseId;
    @NotNull private Long judgeId;
    @NotBlank private String description;
}
