package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ProceedingRequest {
    @NotNull private Long hearingId;
    private String notes;
    private String status;
}
