package com.justiceserve.dto.response;

import com.justiceserve.entity.AuditLog;
import lombok.Data;
import java.time.LocalDateTime;

@Data
public class AuditLogResponse {
    private Long auditLogId;
    private Long userId;
    private String userName;
    private String action;
    private String resource;
    private LocalDateTime timestamp;

    public static AuditLogResponse from(AuditLog a) {
        AuditLogResponse r = new AuditLogResponse();
        r.auditLogId = a.getAuditLogId();
        r.userId = a.getUser().getUserId();
        r.userName = a.getUser().getName();
        r.action = a.getAction(); r.resource = a.getResource();
        r.timestamp = a.getTimestamp();
        return r;
    }
}
