package com.justiceserve.dto.response;

import com.justiceserve.entity.Citizen;
import com.justiceserve.entity.User;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CitizenResponse {
    private Long citizenId;
    private Long userId;
    private String name;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
    private User.Status status;

    public static CitizenResponse from(Citizen c) {
        CitizenResponse r = new CitizenResponse();
        r.citizenId = c.getCitizenId(); r.userId = c.getUser().getUserId();
        r.name = c.getName(); r.dob = c.getDob(); r.gender = c.getGender();
        r.address = c.getAddress(); r.contactInfo = c.getContactInfo();
        r.status = c.getStatus();
        return r;
    }
}
