package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/** POST /api/auth/login – Angular sends email + password, gets JWT back. */
@Data
public class LoginRequest {
    @Email @NotBlank
    private String email;
    @NotBlank
    private String password;
}
