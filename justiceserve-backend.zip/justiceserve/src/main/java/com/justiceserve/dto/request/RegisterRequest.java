package com.justiceserve.dto.request;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

/**
 * RegisterRequest – POST /api/auth/register
 *
 * Role field is intentionally absent.
 * Every new user is registered as CITIZEN automatically.
 * Admin assigns other roles via PATCH /api/users/{id}/change-role
 */
@Data
public class RegisterRequest {
    @NotBlank(message = "Name is required")
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Email must be valid")
    private String email;

    @NotBlank(message = "Password is required")
    private String password;

    private String phone;
}
