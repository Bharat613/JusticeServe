package com.justiceserve.dto.request;

import com.justiceserve.entity.Report;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ReportRequest {
    @NotNull private Report.ReportScope scope;
    @NotNull private Long generatedBy;
}
