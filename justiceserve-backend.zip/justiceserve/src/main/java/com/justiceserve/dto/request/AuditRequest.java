package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class AuditRequest {
    @NotNull private Long officerId;
    @NotBlank private String scope;
    private String findings;
}
