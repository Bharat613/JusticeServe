package com.justiceserve.dto.response;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Returned from POST /api/auth/login
 * Angular stores token in localStorage and sends as: Authorization: Bearer <token>
 */
@Data @AllArgsConstructor
public class AuthResponse {
    private String token;
    private String tokenType = "Bearer";
    private Long userId;
    private String name;
    private String email;
    private String role;

    public AuthResponse(String token, Long userId, String name, String email, String role) {
        this.token = token; this.userId = userId;
        this.name = name; this.email = email; this.role = role;
    }
}
