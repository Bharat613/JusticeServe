package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;
import java.time.LocalDate;

@Data
public class CitizenRequest {
    @NotNull private Long userId;
    @NotBlank private String name;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
}
