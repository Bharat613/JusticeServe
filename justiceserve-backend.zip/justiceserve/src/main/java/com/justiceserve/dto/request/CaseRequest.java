package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CaseRequest {
    @NotNull private Long citizenId;
    private Long lawyerId;
    @NotBlank private String title;
    private String description;
}
