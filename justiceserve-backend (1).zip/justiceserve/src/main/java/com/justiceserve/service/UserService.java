package com.justiceserve.service;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.User;
import java.util.List;

public interface UserService {
    List<UserResponse> getAllUsers();
    UserResponse getUserById(Long id);
    List<UserResponse> getUsersByRole(User.Role role);
    UserResponse updateUserStatus(Long id, User.Status status);
    void deleteUser(Long id);
}
