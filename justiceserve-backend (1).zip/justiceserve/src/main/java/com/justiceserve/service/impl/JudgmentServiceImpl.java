package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CourtOrderRequest;
import com.justiceserve.dto.request.JudgmentRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.response.CourtOrderResponse;
import com.justiceserve.dto.response.JudgmentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.JudgmentService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * JudgmentServiceImpl – Judgment and court order management.
 * DB tables: judgments, court_orders
 * Side effects: finalizing judgment updates cases.status=CLOSED
 */
@Service
@RequiredArgsConstructor
public class JudgmentServiceImpl implements JudgmentService {

    private final JudgmentRepository judgmentRepo;
    private final CourtOrderRepository orderRepo;
    private final CaseRepository caseRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;

    /** Inserts row into judgments with status=DRAFT, case status→JUDGMENT_PENDING. */
    @Override
    @Transactional
    public JudgmentResponse recordJudgment(JudgmentRequest req) {
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));
        c.setStatus(Case.CaseStatus.JUDGMENT_PENDING);
        caseRepo.save(c);
        Judgment j = Judgment.builder().caseEntity(c).judge(judge).summary(req.getSummary()).build();
        return JudgmentResponse.from(judgmentRepo.save(j));
    }

    @Override
    public JudgmentResponse getJudgmentById(Long id) {
        return JudgmentResponse.from(judgmentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Judgment not found: " + id)));
    }

    @Override
    public List<JudgmentResponse> getAllJudgments() {
        return judgmentRepo.findAll().stream().map(JudgmentResponse::from).toList();
    }

    @Override
    public List<JudgmentResponse> getJudgmentsByCase(Long caseId) {
        return judgmentRepo.findByCaseEntityCaseId(caseId).stream().map(JudgmentResponse::from).toList();
    }

    /**
     * Finalizes judgment: status→FINAL, case status→CLOSED.
     * Notifies citizen and lawyer.
     */
    @Override
    @Transactional
    public JudgmentResponse finalizeJudgment(Long id) {
        Judgment j = judgmentRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Judgment not found: " + id));
        j.setStatus(Judgment.JudgmentStatus.FINAL);
        Judgment saved = judgmentRepo.save(j);

        Case c = saved.getCaseEntity();
        c.setStatus(Case.CaseStatus.CLOSED);
        caseRepo.save(c);

        String msg = "Judgment finalized for case: " + c.getTitle();
        NotificationRequest n1 = new NotificationRequest();
        n1.setUserId(c.getCitizen().getUser().getUserId());
        n1.setEntityId(saved.getJudgmentId()); n1.setMessage(msg);
        n1.setCategory(Notification.NotificationCategory.JUDGMENT);
        notificationService.send(n1);

        if (c.getLawyer() != null) {
            NotificationRequest n2 = new NotificationRequest();
            n2.setUserId(c.getLawyer().getUserId());
            n2.setEntityId(saved.getJudgmentId()); n2.setMessage(msg);
            n2.setCategory(Notification.NotificationCategory.JUDGMENT);
            notificationService.send(n2);
        }
        return JudgmentResponse.from(saved);
    }

    /** Inserts row into court_orders table. */
    @Override
    public CourtOrderResponse issueOrder(CourtOrderRequest req) {
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));
        CourtOrder o = CourtOrder.builder().caseEntity(c).judge(judge).description(req.getDescription()).build();
        return CourtOrderResponse.from(orderRepo.save(o));
    }

    @Override
    public CourtOrderResponse getOrderById(Long id) {
        return CourtOrderResponse.from(orderRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id)));
    }

    @Override
    public List<CourtOrderResponse> getAllOrders() {
        return orderRepo.findAll().stream().map(CourtOrderResponse::from).toList();
    }

    @Override
    public List<CourtOrderResponse> getOrdersByCase(Long caseId) {
        return orderRepo.findByCaseEntityCaseId(caseId).stream().map(CourtOrderResponse::from).toList();
    }

    /** Updates court_orders.status column. */
    @Override
    public CourtOrderResponse updateOrderStatus(Long id, CourtOrder.OrderStatus status) {
        CourtOrder o = orderRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + id));
        o.setStatus(status);
        return CourtOrderResponse.from(orderRepo.save(o));
    }
}
