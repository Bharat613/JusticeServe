package com.justiceserve.service;

import com.justiceserve.dto.request.CaseRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CaseResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.Case;
import com.justiceserve.entity.CitizenDocument;
import java.util.List;

public interface CaseService {
    CaseResponse fileCase(CaseRequest request);
    CaseResponse getCaseById(Long id);
    List<CaseResponse> getAllCases();
    List<CaseResponse> getCasesByCitizen(Long citizenId);
    List<CaseResponse> getCasesByLawyer(Long lawyerId);
    List<CaseResponse> getCasesByStatus(Case.CaseStatus status);
    CaseResponse updateCaseStatus(Long id, Case.CaseStatus status);
    CaseResponse assignLawyer(Long caseId, Long lawyerId);
    CaseResponse assignJudge(Long caseId, Long judgeId);
    DocumentResponse addDocument(Long caseId, DocumentRequest request);
    List<DocumentResponse> getDocuments(Long caseId);
    DocumentResponse verifyDocument(Long docId, CitizenDocument.VerificationStatus status);
}
