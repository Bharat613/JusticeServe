package com.justiceserve.service.impl;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.User;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.UserRepository;
import com.justiceserve.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * UserServiceImpl – Admin-level user management.
 * Updates users table for status/role changes.
 */
@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository repo;

    /** Reads all rows from users table. Admin only. */
    @Override
    public List<UserResponse> getAllUsers() {
        return repo.findAll().stream().map(UserResponse::from).toList();
    }

    @Override
    public UserResponse getUserById(Long id) {
        return UserResponse.from(repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id)));
    }

    /** Filters users table by role column. Used to populate judge/lawyer dropdowns in Angular. */
    @Override
    public List<UserResponse> getUsersByRole(User.Role role) {
        return repo.findByRole(role).stream().map(UserResponse::from).toList();
    }

    /**
     * Updates users.status column.
     * INACTIVE users cannot log in (locked by Spring Security).
     */
    @Override
    public UserResponse updateUserStatus(Long id, User.Status status) {
        var user = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        user.setStatus(status);
        return UserResponse.from(repo.save(user));
    }

    /**
     * Updates users.role column. Admin-only operation.
     * After role change, user must log out and log back in to receive
     * a new JWT with the updated role — the new portal will then be shown.
     */
    @Override
    public UserResponse updateUserRole(Long id, User.Role role) {
        var user = repo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
        user.setRole(role);
        return UserResponse.from(repo.save(user));
    }

    @Override
    public void deleteUser(Long id) {
        if (!repo.existsById(id)) throw new ResourceNotFoundException("User not found: " + id);
        repo.deleteById(id);
    }
}
