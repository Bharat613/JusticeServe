package com.justiceserve.service.impl;

import com.justiceserve.dto.request.HearingRequest;
import com.justiceserve.dto.request.NotificationRequest;
import com.justiceserve.dto.request.ProceedingRequest;
import com.justiceserve.dto.response.HearingResponse;
import com.justiceserve.dto.response.ProceedingResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.HearingService;
import com.justiceserve.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * HearingServiceImpl – Hearing scheduling and proceedings.
 * DB tables: hearings, proceedings
 * Side effects: updates cases.status, sends notifications
 */
@Service
@RequiredArgsConstructor
public class HearingServiceImpl implements HearingService {

    private final HearingRepository hearingRepo;
    private final ProceedingRepository proceedingRepo;
    private final CaseRepository caseRepo;
    private final UserRepository userRepo;
    private final NotificationService notificationService;

    /**
     * Inserts row into hearings table.
     * Updates associated case status to HEARING_SCHEDULED.
     * Notifies citizen and lawyer.
     */
    @Override
    @Transactional
    public HearingResponse scheduleHearing(HearingRequest req) {
        Case c = caseRepo.findById(req.getCaseId())
                .orElseThrow(() -> new ResourceNotFoundException("Case not found: " + req.getCaseId()));
        User judge = userRepo.findById(req.getJudgeId())
                .orElseThrow(() -> new ResourceNotFoundException("Judge not found: " + req.getJudgeId()));

        Hearing savedHearing = hearingRepo.save(Hearing.builder()
                .caseEntity(c).judge(judge).date(req.getDate()).time(req.getTime()).build());

        c.setStatus(Case.CaseStatus.HEARING_SCHEDULED);
        caseRepo.save(c);

        String msg = "Hearing scheduled for case '" + c.getTitle() + "' on " + req.getDate() + " at " + req.getTime();
        NotificationRequest citizenNotif = new NotificationRequest();
        citizenNotif.setUserId(c.getCitizen().getUser().getUserId());
        citizenNotif.setEntityId(savedHearing.getHearingId());
        citizenNotif.setMessage(msg);
        citizenNotif.setCategory(Notification.NotificationCategory.HEARING);
        notificationService.send(citizenNotif);

        if (c.getLawyer() != null) {
            NotificationRequest lawyerNotif = new NotificationRequest();
            lawyerNotif.setUserId(c.getLawyer().getUserId());
            lawyerNotif.setEntityId(savedHearing.getHearingId());
            lawyerNotif.setMessage(msg);
            lawyerNotif.setCategory(Notification.NotificationCategory.HEARING);
            notificationService.send(lawyerNotif);
        }
        return HearingResponse.from(savedHearing);
    }

    @Override
    public HearingResponse getHearingById(Long id) {
        return HearingResponse.from(hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id)));
    }

    @Override
    public List<HearingResponse> getAllHearings() {
        return hearingRepo.findAll().stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByCase(Long caseId) {
        return hearingRepo.findByCaseEntityCaseId(caseId).stream().map(HearingResponse::from).toList();
    }

    @Override
    public List<HearingResponse> getHearingsByJudge(Long judgeId) {
        return hearingRepo.findByJudgeUserId(judgeId).stream().map(HearingResponse::from).toList();
    }

    /** Updates hearings.status column. */
    @Override
    public HearingResponse updateStatus(Long id, Hearing.HearingStatus status) {
        Hearing h = hearingRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + id));
        h.setStatus(status);
        return HearingResponse.from(hearingRepo.save(h));
    }

    /** Inserts row into proceedings table for a hearing session. */
    @Override
    public ProceedingResponse addProceeding(ProceedingRequest req) {
        Hearing h = hearingRepo.findById(req.getHearingId())
                .orElseThrow(() -> new ResourceNotFoundException("Hearing not found: " + req.getHearingId()));
        Proceeding p = Proceeding.builder().hearing(h).notes(req.getNotes()).status(req.getStatus()).build();
        return ProceedingResponse.from(proceedingRepo.save(p));
    }

    @Override
    public List<ProceedingResponse> getProceedingsByHearing(Long hearingId) {
        return proceedingRepo.findByHearingHearingId(hearingId).stream().map(ProceedingResponse::from).toList();
    }
}
