package com.justiceserve.service.impl;

import com.justiceserve.dto.request.CitizenRequest;
import com.justiceserve.dto.request.DocumentRequest;
import com.justiceserve.dto.response.CitizenResponse;
import com.justiceserve.dto.response.DocumentResponse;
import com.justiceserve.entity.*;
import com.justiceserve.exception.ResourceNotFoundException;
import com.justiceserve.repository.*;
import com.justiceserve.service.CitizenService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * CitizenServiceImpl – Citizen registration and document management.
 * DB tables: citizens, citizen_documents
 */
@Service
@RequiredArgsConstructor
public class CitizenServiceImpl implements CitizenService {

    private final CitizenRepository citizenRepo;
    private final UserRepository userRepo;
    private final CitizenDocumentRepository docRepo;

    /** Inserts new row into citizens table linked to an existing User. */
    @Override
    public CitizenResponse createCitizen(CitizenRequest req) {
        User user = userRepo.findById(req.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + req.getUserId()));
        Citizen c = Citizen.builder()
                .user(user).name(req.getName()).dob(req.getDob())
                .gender(req.getGender()).address(req.getAddress())
                .contactInfo(req.getContactInfo()).status(User.Status.ACTIVE).build();
        return CitizenResponse.from(citizenRepo.save(c));
    }

    @Override
    public CitizenResponse getCitizenById(Long id) {
        return CitizenResponse.from(citizenRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + id)));
    }

    @Override
    public CitizenResponse getCitizenByUserId(Long userId) {
        return CitizenResponse.from(citizenRepo.findByUserUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen profile not found for user: " + userId)));
    }

    @Override
    public List<CitizenResponse> getAllCitizens() {
        return citizenRepo.findAll().stream().map(CitizenResponse::from).toList();
    }

    @Override
    public CitizenResponse updateCitizen(Long id, CitizenRequest req) {
        Citizen c = citizenRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + id));
        c.setName(req.getName()); c.setDob(req.getDob());
        c.setGender(req.getGender()); c.setAddress(req.getAddress());
        c.setContactInfo(req.getContactInfo());
        return CitizenResponse.from(citizenRepo.save(c));
    }

    /** Inserts new row into citizen_documents with status=PENDING. */
    @Override
    public DocumentResponse addDocument(Long citizenId, DocumentRequest req) {
        Citizen c = citizenRepo.findById(citizenId)
                .orElseThrow(() -> new ResourceNotFoundException("Citizen not found: " + citizenId));
        CitizenDocument doc = CitizenDocument.builder()
                .citizen(c).docType(req.getDocType()).fileUri(req.getFileUri()).build();
        return DocumentResponse.fromCitizen(docRepo.save(doc));
    }

    @Override
    public List<DocumentResponse> getDocuments(Long citizenId) {
        return docRepo.findByCitizenCitizenId(citizenId)
                .stream().map(DocumentResponse::fromCitizen).toList();
    }

    /** Updates citizen_documents.verification_status. Clerk action. */
    @Override
    public DocumentResponse verifyDocument(Long docId, CitizenDocument.VerificationStatus status) {
        CitizenDocument doc = docRepo.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(status);
        return DocumentResponse.fromCitizen(docRepo.save(doc));
    }
}
