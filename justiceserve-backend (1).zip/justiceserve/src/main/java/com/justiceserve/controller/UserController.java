package com.justiceserve.controller;

import com.justiceserve.dto.response.UserResponse;
import com.justiceserve.entity.User;
import com.justiceserve.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<UserResponse>> getAll() {
        return ResponseEntity.ok(service.getAllUsers());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getUserById(id));
    }

    @GetMapping("/role/{role}")
    @PreAuthorize("hasAnyRole('ADMIN','CLERK','JUDGE')")
    public ResponseEntity<List<UserResponse>> getByRole(@PathVariable User.Role role) {
        return ResponseEntity.ok(service.getUsersByRole(role));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> updateStatus(@PathVariable Long id,
                                                      @RequestParam User.Status status) {
        return ResponseEntity.ok(service.updateUserStatus(id, status));
    }

    /**
     * Change a user's role — Admin only.
     * PATCH /api/users/{id}/role?role=LAWYER
     *
     * After this call the user must log out and log back in
     * to receive a new JWT with the updated role.
     * Available roles: CITIZEN, LAWYER, JUDGE, CLERK, ADMIN, COMPLIANCE, AUDITOR
     */
    @PatchMapping("/{id}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<UserResponse> updateRole(@PathVariable Long id,
                                                    @RequestParam User.Role role) {
        return ResponseEntity.ok(service.updateUserRole(id, role));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        service.deleteUser(id);
        return ResponseEntity.noContent().build();
    }
}
