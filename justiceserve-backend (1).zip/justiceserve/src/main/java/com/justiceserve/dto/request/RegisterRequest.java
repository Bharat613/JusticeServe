package com.justiceserve.dto.request;

import com.justiceserve.entity.User;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class RegisterRequest {
    @NotBlank private String name;
    @NotBlank @Email private String email;
    @NotBlank private String password;
    @NotNull  private User.Role role;
    private String phone;
}
