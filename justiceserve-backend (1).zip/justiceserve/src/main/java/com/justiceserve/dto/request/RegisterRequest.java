package com.justiceserve.dto.request;

import jakarta.validation.constraints.*;
import lombok.Data;

/**
 * RegisterRequest – used for POST /api/auth/register
 *
 * Role is intentionally removed. Every new user registers as CITIZEN by default.
 * Admin can later change the role via PATCH /api/users/{id}/role
 */
@Data
public class RegisterRequest {
    @NotBlank private String name;
    @NotBlank @Email private String email;
    @NotBlank private String password;
    private String phone;
}
